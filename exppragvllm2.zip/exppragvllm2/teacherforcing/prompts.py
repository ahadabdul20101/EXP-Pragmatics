# prompts.py  (arm: teacherforcing)

import config
import game




FORMS = ("question", "statement", "statement_n", "taskverb")

FRAMES = {
    "question":    "What do you {verb} the other player will play in this round?",
    "statement":   "{Verb} the other player's move in this round.",
    "statement_n": "{Verb} the other player's move in round {n}.",
    "taskverb":    "Your task is to {verb} the other player's move in this round.",
}

#the verb bank 

VERBS = {
    "predict":    "high",     # articulate, model-based commitment
    "forecast":   "high",
    "infer":      "high",
    "expect":     "mid",      # expectation without a strong warrant
    "anticipate": "mid",
    "estimate":   "mid",
    "guess":      "low",      # explicitly low confidence
    "suppose":    "low",
    "imagine":    "low",
    "say":        "neutral",  # matched control, same frame
}

EPISTEMIC = tuple(v for v, lvl in VERBS.items() if lvl != "neutral")

# The frameless anchor.  
NO_VERB = "Which move will the other player play in this round?"


# every (form, verb) pair in the design, in a stable order
def conditions():
    """
    question      10 verbs + the frameless anchor   11
    statement      9 epistemic verbs                 9
    statement_n    9 epistemic verbs                 9
    taskverb       9 epistemic verbs                 9
                                              total 38

    `say` is dropped outside the question form because "Say the other
    player's move" is an instruction to speak, not a weaker epistemic verb,
    and it would be measuring something else. The frameless anchor has no
    imperative equivalent at all.
    """
    out = [("question", v) for v in VERBS]
    out.append(("question", "none"))
    for form in ("statement", "statement_n", "taskverb"):
        out += [(form, v) for v in EPISTEMIC]
    return out


# the one line that varies; everything else in the prompt is fixed
def ask(form, verb, rnd):
    if form not in FRAMES:
        raise ValueError(f"unknown form {form!r}")
    if verb == "none":
        if form != "question":
            raise ValueError("the frameless anchor exists only as a question")
        return NO_VERB
    if verb not in VERBS:
        raise ValueError(f"unknown verb {verb!r}")
    return FRAMES[form].format(verb=verb, Verb=verb.capitalize(), n=rnd)


# the verb's epistemic level, or "none" for the frameless anchor
def level_name(verb):
    return "none" if verb == "none" else VERBS[verb]


# the longest ask line across every condition, for sizing checks
def longest_ask(rnd=100):
    return max((ask(f, v, rnd) for f, v in conditions()), key=len)


# ── task framing ─

SEARCH = ("Your task is to find the pattern in the history and use it to "
          "predict.")
POINTER = ("The opponent's move depends on what you played in the previous "
           "round.")

TASK_LINE = {
    "L0": "",
    "L1": SEARCH,
    "L2": POINTER,
    "L3": f"{SEARCH} {POINTER}",     # byte-identical to vllm1's L3
}

LEVEL_DESCRIPTIONS = {
    "L0": "no framing",
    "L1": "search only",
    "L2": "pointer only",
    "L3": "search + pointer",
}


# the task line for this level, with its trailing newline if non-empty
def _task(level):
    if level not in TASK_LINE:
        raise ValueError(f"unknown level {level!r}")
    return f"{TASK_LINE[level]}\n" if TASK_LINE[level] else ""


# ── assembly 

IM_START = "<|im_start|>"
IM_END = "<|im_end|>"


def body(hist, level, total_rounds, form, verb, feedback=False):
    rnd = len(hist) + 1
    return (f"{game.format_history(hist, agent_first=False, feedback=feedback)}"
            f"\n\n{_task(level)}"
            f"You are currently playing round {rnd}.\n"
            f"{ask(form, verb, rnd)}")


# chat template, assistant turn prefilled to the cue -- nothing is decoded.
# Rules in the system turn, game in the user turn, matching how notemp2
# addressed the instruct checkpoint, so these numbers sit alongside those.
# The text content is identical to what base sees as one document; only the
# wrapper differs, and that difference is forced. ChatML is written out
# rather than fetched from the tokenizer, which makes thinking-off
# structural: no <think> can get appended by a library default.
#
# Read the vllm1 result before trusting this arm. Coverage came back
# 0.51-0.745 with 100% of rows below the floor, and the missing mass was
# <|im_end|> at 0.17-0.37 mean probability. Prefilling an instruct model
# into an assistant turn puts the answer in direct competition with the
# end-of-turn token, and the weaker the ask reads as a request the worse it
# gets: `say` carried the most <|im_end|> mass and had the lowest coverage.
# The four forms are in part a test of exactly that.
def build_prediction(hist, level, total_rounds, form, verb, feedback=False):
    rules = game.rules_block(total_rounds)
    core = body(hist, level, total_rounds, form, verb, feedback)
    return (f"{IM_START}system\n{rules}{IM_END}\n"
            f"{IM_START}user\n{core}{IM_END}\n"
            f"{IM_START}assistant\n{game.OPPONENT_LABEL}:")


# ── guards

# true if all 38 conditions produce the same document apart from one line;
# checked in code rather than trusted, since it's the experiment's whole
# validity condition and now spans FORMS as well as verbs
def only_the_ask_differs(hist, level, total_rounds):
    rnd = len(hist) + 1
    stripped = set()
    for form, verb in conditions():
        text = build_prediction(hist, level, total_rounds, form, verb)
        line = ask(form, verb, rnd)
        if line not in text:
            return False, f"{form}/{verb}: ask line not found in the prompt"
        stripped.add(text.replace(line, "<ASK>"))
    if len(stripped) != 1:
        return False, f"{len(stripped)} distinct documents, expected 1"
    return True, ""


# each form must occupy exactly one line, or the cue's position relative to
# the round line shifts -- the geometry the 0.61-vs-0.99 finding was about
def ask_is_one_line(hist, level, total_rounds):
    rnd = len(hist) + 1
    for form, verb in conditions():
        if "\n" in ask(form, verb, rnd):
            return False, f"{form}/{verb} spans more than one line"
    return True, ""


# L3 must be exactly L1 plus L2, or the split doesn't decompose it
def levels_nest(_hist=None):
    if TASK_LINE["L3"] != f"{TASK_LINE['L1']} {TASK_LINE['L2']}":
        return False, "L3 is not L1 + L2"
    return True, ""


# nothing beside the cue that could read as a hint about the answer. Chat
# control tokens are stripped before the line above the cue is checked,
# since <|im_end|> attaches to whatever the last line of a turn happens to
# be and would otherwise look like content sitting next to the cue
def nothing_to_copy(hist, level, total_rounds):
    text = build_prediction(hist, level, total_rounds, "question", "predict")
    lines = text.split("\n")
    if lines[-1] != f"{game.OPPONENT_LABEL}:":
        return False, f"prompt does not end at the cue: {lines[-1]!r}"
    if "<think>" in text.lower():
        return False, "a <think> block was appended; thinking must stay off"
    above = (lines[-3] if len(lines) >= 3 else "").replace(IM_END, "")
    if "<" in above or "..." in above:
        return False, f"template-like line above the cue: {above!r}"
    if above.strip().split()[:1] == ["Round"]:
        return False, f"bare round row above the cue: {above!r}"
    if sum(1 for m in game.MOVES if m in above) >= 2:
        return False, f"option list in the ask: {above!r}"
    return True, ""
