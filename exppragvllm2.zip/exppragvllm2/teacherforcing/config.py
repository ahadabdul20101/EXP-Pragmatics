# config.py  (arm: teacherforcing)
# exppragvllm -- the pragmatics experiment on the notemp2 architecture.
#
# The instruct checkpoint, scored exactly like base: the chat template gets
# applied, the assistant turn is prefilled up to the cue, and one token is
# scored there through /v1/completions. Nothing is generated and nothing is
# parsed, so truncation can't happen.
#
# The cost of that: prefilling puts the model past the point where any
# reasoning would go, so this arm only measures its immediate next-token
# belief, not what it would conclude given room to work. That's a real
# limitation, which is why instructnormal exists alongside it. A
# base-vs-teacherforcing difference means "the verb shifts the immediate
# distribution differently on this checkpoint" -- never "instruct reasons
# better about the verb".
#
# The manipulation is one word. Every prompt is byte-identical except the
# verb in the question line. Because the transcripts are scripted, every
# verb sees the same history at the same round, so verbs compare round by
# round instead of as group means.
#
# The geometry is notemp2's, and every part of it has been measured:
#
#   an answer template   30 cycle probes, varying only what sits next to the
#                        cue:  nothing J10 F10 M10 90.0% | "..." J16 F10 M4
#                        73.3% | "<J, F, or M>" J3 F5 M22 40.0% | "<move>"
#                        J1 F1 M28 30.0%. Coverage held at 0.99 for all four,
#                        so only the answer spread shows the effect.
#   an option list       rotated three ways: M 60/60 under M/J/F, never J
#                        under F/M/J, chance accuracy throughout.
#   a "Round N" line     directly above the cue makes the cue read like a
#                        table row: 0.61 coverage with it, 0.99 without.
#
# All three are absent, on every arm, so the question line stays identical
# everywhere. --self-test fails if any of them reappear.

import os


# reads an int env var, falling back to d
def _int(n, d):
    return int(os.environ.get(n, d))


# reads a string env var, falling back to d
def _str(n, d):
    return os.environ.get(n, d)


# reads a float env var, falling back to d
def _float(n, d):
    return float(os.environ.get(n, d))


ARM = "teacherforcing"
MODEL_KIND = _str("MODEL_KIND", "instruct")
LABEL_SCHEME = _str("LABEL_SCHEME", "neutral")

# This arm reads logprobs instead of generating, so serve.py has to start
# the server with --max-logprobs. Ask for more logprobs than that at request
# time and vLLM just rejects it.
SCORES_LOGPROBS = True
GENERATES = False

# ── design ───────────────────────────────────────────────────────────────────

TOTAL_ROUNDS = _int("TOTAL_ROUNDS", 100)

# Round 1 has no history, so there's nothing yet to predict from.
PROBE_FROM = _int("PROBE_FROM", 2)

# `fixed` got replaced by `random`. random is the falsifier: nothing
# predicts its next move, so 33.3% is a hard ceiling. A verb ordering that
# also shows up on random is a confidence style, not prediction, and
# without this cell the two can't be told apart.
OPPONENTS = _str("OPPONENTS", "cycle,mirror,tft,random").split(",")

# L0, L2, L3. vllm1 ran L0 against a single L3 that was actually two
# manipulations bundled into one string, and both fired at once:
#
#   search   "find the pattern in the history" -- has no truth value, and
#            drove length and truncation. cycle went 1467 -> 10068
#            characters, random truncated 87% of the time.
#   pointer  "the opponent's move depends on what you played" -- true for
#            mirror and tft, false for cycle and random, and this is what
#            drove the SIGN of the accuracy change: mirror +20.8, cycle
#            -18.8.
#
# Nothing separated them because they always travelled together. L2 is the
# pointer alone, so it does. L1 (search alone) completes the 2x2 and is
# nearly free here: LEVELS=L0,L1,L2,L3.
LEVELS = _str("LEVELS", "L0,L2,L3").split(",")

# Feedback stays off. It's a second manipulation, and crossing it with the
# verbs would double every arm without telling us anything about the
# question at hand.
FEEDBACK = False

SEEDS = [int(s) for s in _str("SEEDS", "1,2,3").split(",")]

# Scripted agent moves are random. An agent that played the correct counter
# would make its own column a fixed function of the opponent's, so either
# column would give away the answer and tft would collapse into a cycle.
# Random keeps the two columns independent, which is what makes the
# cross-stream lookup genuinely necessary.
SCRIPTED_AGENT_POLICY = "random"


# ── the form axis ────────────────────────────────────────────────────────────
#
# vllm1 asked one question twelve ways and found the verb moved coverage by
# 0.20-0.25 while the opponent only moved it by 0.01-0.03. So the verb was
# changing how the answer got formatted, not what it actually was. Eleven of
# the twelve conditions were questions though, so nothing in that run could
# say whether the driver was the verb or just the fact that it was phrased
# as a question.
#
#   question      interrogative, verb inside a fixed frame   (vllm1's form)
#   statement     imperative, the verb carries the whole ask
#   statement_n   the same imperative, naming the round explicitly
#   taskverb      the vllm1 `task` condition, with the verb now varied
#
# statement_n exists because naming the round is a second difference that
# would otherwise ride along inside `statement`. Keeping both turns the
# deixis effect into one measurable cell per verb instead of a confound.
#
# taskverb is vllm1's broken condition, opened up. `task` there ran at 0.58
# coverage against 0.82 for everything else, and answered J 91.2% of the
# time on tft. That was one prompt with one verb baked in, so it couldn't
# say whether the floor came from the imperative frame or from `predict`
# sitting inside it. Now the frame is held fixed and the verb moves, which
# settles it.
FORMS = _str("FORMS", "question,statement,statement_n,taskverb").split(",")

# ── the probe schedule ───────────────────────────────────────────────────────
#
# Which rounds get a probe. PROBE_DENSE_TO = 0 means every round.
#
# On a teacher-forced arm a probe is a single token, so every round is
# affordable and time-to-belief gets the finest resolution available. On a
# generating arm each probe is a full generation, and the belief curve is
# usually decided in the first twenty or thirty rounds anyway: vllm1's base
# cycle accuracy jumped from 55% to 75% between rounds 11-19 and 20-28 and
# stayed flat after that. So: dense early, sparse late.
PROBE_DENSE_TO = _int("PROBE_DENSE_TO", 0)
PROBE_SPARSE_EVERY = _int("PROBE_SPARSE_EVERY", 1)


# which rounds actually get probed, given the dense/sparse schedule above
def probe_rounds(total=None):
    total = TOTAL_ROUNDS if total is None else total
    out = []
    for r in range(PROBE_FROM, total + 1):
        if PROBE_DENSE_TO == 0 or r <= PROBE_DENSE_TO:
            out.append(r)
        elif (r - PROBE_DENSE_TO) % PROBE_SPARSE_EVERY == 0:
            out.append(r)
    return out

# ── vLLM ─────────────────────────────────────────────────────────────────────

VLLM_HOST = _str("VLLM_HOST", "127.0.0.1")
VLLM_PORT = _int("VLLM_PORT", 8000)
VLLM_PYLIBS = _str("VLLM_PYLIBS", "/scratch/mpi_inf/abah00001/vllm_019")
MODEL_PATHS = {"base": "Qwen/Qwen3.5-9B-Base", "instruct": "Qwen/Qwen3.5-9B"}
SERVED_NAMES = {"base": "qwen35-9b-base", "instruct": "qwen35-9b"}
VLLM_MODEL_PATH = MODEL_PATHS[MODEL_KIND]
VLLM_SERVED_NAME = SERVED_NAMES[MODEL_KIND]

# 16384, not 8192. At 100 rounds the prompt is about 1200 tokens here and
# about 1900 in relationderivation; add MAX_NEW_TOKENS at 5000 and the total
# gets close to the old ceiling, and a request over max-model-len just gets
# rejected.
VLLM_MAX_MODEL_LEN = _int("VLLM_MAX_MODEL_LEN", 16384)
VLLM_GPU_MEM_UTIL = _float("VLLM_GPU_MEM_UTIL", 0.85)
VLLM_STARTUP_TIMEOUT_S = _int("VLLM_STARTUP_TIMEOUT_S", 1200)

# The server rejects any request asking for more logprobs than it was
# started with. 20 is also what notemp2 used, so the coverage numbers stay
# comparable.
VLLM_MAX_LOGPROBS = _int("VLLM_MAX_LOGPROBS", 20)
TOP_LOGPROBS = VLLM_MAX_LOGPROBS

# ── sampling (generating arms only; kept here so all four configs match) ─────
#
# These match notemp2's values exactly, so the numbers sit alongside those
# runs. PRESENCE_PENALTY especially -- it's the documented lever against
# endless repetition, and a transformers-based port of this harness once
# silently dropped it because transformers has no such parameter.
ENABLE_THINKING = _int("ENABLE_THINKING", 0) == 1
TEMPERATURE = _float("TEMPERATURE", 0.7)
TOP_P = _float("TOP_P", 0.8)
TOP_K = _int("TOP_K", 20)
MIN_P = _float("MIN_P", 0.0)
PRESENCE_PENALTY = _float("PRESENCE_PENALTY", 1.5)
MAX_NEW_TOKENS = _int("MAX_NEW_TOKENS", 5000)

RETRY_MAX = _int("RETRY_MAX", 5)

# A response with no answer line counts as a failure so the retry loop
# fires, rather than falling back to whatever move was last mentioned. That
# fallback used to score 30-36% (chance) because it picks up whatever move
# appeared last in an unfinished analysis, often one being ruled out:
# "would likely play F and not J" parses as J.
REQUIRE_ANSWER_LINE = _int("REQUIRE_ANSWER_LINE", 1) == 1

# vLLM batches continuously, so this is what feeds it. Base is one token per
# call and can take a lot of concurrency.
MAX_CONCURRENT = _int("MAX_CONCURRENT", 24)
REQUEST_TIMEOUT_S = _int("REQUEST_TIMEOUT_S", 300)

# ── output ───────────────────────────────────────────────────────────────────
#
# The job writes to scratch and copies to the results folder on completion,
# so results land under exppragvllm2/results/<arm>/ as expected.
RESULTS_DIR = _str("RESULTS_DIR",
                   f"/scratch/mpi_inf/abah00001/exppragvllm2_results/{ARM}")
FINAL_COPY_DIR = _str("FINAL_COPY_DIR",
                      f"/home/abah00001/expprag/exppragvllm2/results/{ARM}")


# the filename prefix every database for this arm shares
def db_prefix():
    return f"{ARM}_{MODEL_KIND}_{LABEL_SCHEME}"
