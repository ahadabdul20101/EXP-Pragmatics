#!/usr/bin/env python3
# belief.py -- time to correct belief establishment.
#
#   python3 belief.py --dir ../results/rulecarry
#   python3 belief.py --dir ../results/rulecarry --run 5      # stricter
#   python3 belief.py --dir ../results/base                   # works anywhere
#
# Why this measure exists: vllm1's group means came back null on the verb
# hypothesis -- within-level spread exceeded between-level spread in 17 of
# 18 cells, and the paired tests scattered. A mean over 99 rounds throws
# away the shape of the curve, and the shape is where the signal actually
# was. base cycle went 55% -> 75% between rounds 11-19 and 20-28 and then
# sat flat; every level crossed 70% in the same band. A measure that reads
# WHEN that happens, per cell, has far more resolution than one that
# averages over it.
#
# Two definitions, and they answer different questions:
#
#   derived    the first round that begins a run of RUN consecutive
#              rule-correct predictions. Works on every arm and every mode,
#              including the teacher-forced ones where a probe is one token
#              and nothing gets written. This is the primary measure.
#
#   stated     the first round whose `rule_stated` sentence names the right
#              strategy, and stays right afterwards. Generating mode only,
#              and only when RULE_PROBE was on.
#
# Read together they separate two things a single accuracy number can't:
#   stated BEFORE derived   the model holds a belief it can't yet act on
#   derived BEFORE stated   it's pattern-matching without a model
#   neither                 nothing was learned in the window
#
# Censoring is the point, not a nuisance. A cell that never establishes a
# belief has no number, and dropping those cells would just report the
# mean of the ones that happened to succeed. Every table here prints the
# reached rate beside the median, and the median is over reached cells
# only -- a cell with `reached` well below 100% has a median that describes
# a subset.
#
# `rule_correct` is scored against what the POLICY says, not what was
# played, which is why it's the right target: on a counter deviation round
# the opponent departs from its own rule, and a model that's learned the
# rule should be wrong there. Using move accuracy would punish exactly the
# behaviour this measure is looking for.

import argparse
import glob
import math
import os
import re
import sqlite3
import statistics
from collections import defaultdict

# What counts as the right strategy, per opponent. Applied to the stated
# sentence, lowercased. Deliberately generous -- the question is whether
# the model has the idea, not whether it phrased it the way the harness
# would.
#
# need/forbid rather than a list of phrasings. The first version enumerated
# wordings and kept missing them: the model writes "copies the move you
# played", "repeats the move you played", "plays the move you made" and
# "mimics your move" for the same belief, and a pattern that only accepted
# the first made the five-in-a-row criterion fail on a model that was right
# every time, just in slightly different words.
#
# The real distinctions are semantic, and there are only three:
#
#                mentions "beats"   mentions "previous/last"
#   counter            yes                   no
#   tft                yes                   yes
#   mirror             no                    yes
#
# So `forbid` is what separates them, and `need` can stay loose. counter
# and tft are mutually exclusive by construction, which is what a keyword
# scorer usually gets wrong.
#
# Scored HERE and not in the job, so revising this judgement never costs
# GPU time -- the sentences are stored verbatim in `rule_stated`.

_PREV = r"previous|last|prior|preceding|earlier|before"
_BEAT = r"beat|counter|defeat|wins? against"

RULE_RULES = {
    # plays what beats your move THIS round
    "counter": dict(need=[_BEAT], forbid=[_PREV]),
    # plays what beats your move LAST round
    "tft":     dict(need=[_BEAT, _PREV], forbid=[]),
    # plays your move from last round. Must NOT mention beats, or it is tft.
    "mirror":  dict(need=[r"cop(y|ies|ying)|repeat|mimic|mirror|imitat"
                          r"|match(es|ing)?|plays? the (same )?move you"
                          r"|plays? what(ever)? you",
                          _PREV],
                    forbid=[_BEAT]),
    # a fixed sequence that ignores you
    "cycle":   dict(need=[r"cycl|rotat|fixed (order|sequence|pattern|rotation)"
                          r"|repeat(s|ing)? the same sequence"
                          r"|ignore[s]? (me|my|you|your|what)"],
                    forbid=[]),
    "random":  dict(need=[r"random|no (clear )?pattern|unpredictab"
                          r"|by chance"],
                    forbid=[]),
}


# true if the sentence names the opponent's actual policy
def rule_is_right(opponent, sentence):
    spec = RULE_RULES.get(opponent)
    if not spec or not sentence:
        return False
    t = sentence.lower()
    if any(re.search(f, t) for f in spec["forbid"]):
        return False
    return all(re.search(n, t) for n in spec["need"])


# loads every round/clean row from the given database files
def load(paths):
    rows = []
    for p in paths:
        c = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        c.row_factory = sqlite3.Row
        try:
            rows += [dict(r) for r in c.execute("SELECT * FROM clean")]
        except sqlite3.Error:
            try:
                rows += [dict(r) for r in c.execute("SELECT * FROM rounds")]
            except sqlite3.Error:
                pass
        c.close()
    return rows


# rule_correct where the arm has it, prediction_correct otherwise. base and
# instructnormal don't store rule_correct, and on those arms the opponent
# never deviates, so the two are the same thing.
def _target(row):
    v = row.get("rule_correct")
    return row.get("prediction_correct") if v is None else v


# the first round that begins `run` consecutive correct predictions.
# Returns (round, censored). Rounds are taken in order and the run must be
# consecutive in the probe schedule, not in game rounds: on a generating
# arm the schedule thins out after round 30, and requiring consecutive
# game rounds there would make the criterion unreachable by construction.
def first_run(rows, run):
    seq = sorted(rows, key=lambda r: r["round_num"])
    hits = [_target(r) for r in seq]
    for i in range(len(hits) - run + 1):
        window = hits[i:i + run]
        if all(h == 1 for h in window):
            return seq[i]["round_num"], False
    return None, True


# the first round beginning `run` consecutive correct statements. Same
# criterion as first_run, deliberately. An earlier version required the
# stated rule to be right and stay right for every remaining probe, while
# the derived measure only asked for a run of 5. That made the two
# incomparable: near the end of the game "all remaining" is one or two
# probes, so late convergence was far easier to satisfy than early
# convergence, and part of the gap in table 6 was an artefact of the
# criteria rather than of the model.
def first_stated(rows, run):
    seq = [r for r in sorted(rows, key=lambda x: x["round_num"])
           if r.get("rule_stated")]
    if not seq:
        return None, True
    opp = seq[0]["opponent"]
    if opp not in RULE_RULES:
        return None, True
    good = [rule_is_right(opp, r["rule_stated"]) for r in seq]
    for i in range(len(good) - run + 1):
        if all(good[i:i + run]):
            return seq[i]["round_num"], False
    return None, True


def med(xs):
    xs = [x for x in xs if x is not None]
    return statistics.median(xs) if xs else None


def f(v, w=8, dp=1):
    return f"{v:>{w}.{dp}f}" if isinstance(v, (int, float)) else f"{'—':>{w}}"


# one cell per (form, verb, level, rules, opponent, seed)
def cells_of(rows):
    g = defaultdict(list)
    for r in rows:
        g[(r.get("form") or "question", r["verb"], r["task_level"],
           r.get("rules") or "given", r["opponent"], r["seed"])].append(r)
    return g


def table(title, note, rows, keyfn, labels, run, stated=False):
    print(title)
    print(note)
    g = defaultdict(list)
    for key, cell in cells_of(rows).items():
        rnd, cens = (first_stated(cell, run) if stated
                     else first_run(cell, run))
        g[keyfn(key)].append((rnd, cens))
    width = max(len(l) for l in labels) + 2 if labels else 12
    print(f"   {'':<{width}}{'cells':>7}{'reached':>9}{'median':>9}"
          f"{'q1':>7}{'q3':>7}")
    for lab in labels:
        got = g.get(lab)
        if not got:
            continue
        reached = [r for r, c in got if not c]
        pct = 100 * len(reached) / len(got)
        qs = sorted(reached)
        q1 = qs[len(qs) // 4] if len(qs) >= 4 else None
        q3 = qs[3 * len(qs) // 4] if len(qs) >= 4 else None
        print(f"   {lab:<{width}}{len(got):>7}{pct:>8.1f}%{f(med(reached), 9)}"
              f"{f(q1, 7, 0)}{f(q3, 7, 0)}")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--run", type=int, default=5,
                    help="consecutive correct probes that establish a belief")
    ap.add_argument("--opponents", nargs="+", default=None)
    a = ap.parse_args()

    paths = sorted(glob.glob(os.path.join(a.dir, "*_run*.db")))
    if not paths:
        raise SystemExit(f"no databases in {a.dir}")
    rows = load(paths)
    if a.opponents:
        rows = [r for r in rows if r["opponent"] in a.opponents]
    if not rows:
        raise SystemExit("no usable rows")

    arms = sorted({(r.get("arm"), r.get("model_kind")) for r in rows})
    print(f"\n{len(rows)} usable rows from {len(paths)} database(s)")
    print(f"arms: {arms}")
    if len(arms) > 1:
        print("  WARNING  more than one arm or mode is pooled here. Split the\n"
              "           directory before reading anything below: a belief\n"
              "           curve averaged across measurement regimes is not a\n"
              "           belief curve.")
    print(f"criterion: {a.run} consecutive rule-correct probes\n")

    opps = sorted({r["opponent"] for r in rows})
    forms = sorted({(r.get("form") or "question") for r in rows})
    levels = sorted({r["task_level"] for r in rows})
    verbs = sorted({r["verb"] for r in rows})

    print("=" * 70)
    print("1. TIME TO BELIEF, DERIVED  (by opponent)")
    print("=" * 70)
    table("", "   `reached` is the share of cells that ever established a\n"
              "   belief. Read it FIRST: a median over 40% of cells is the\n"
              "   median of the cells that happened to succeed.\n",
          rows, lambda k: k[4], opps, a.run)

    print("=" * 70)
    print("2. BY TASK LEVEL")
    print("=" * 70)
    table("", "   L2 is the pointer alone, L3 the pointer plus the search\n"
              "   instruction. If L3 is slower than L2, the search is costing\n"
              "   rounds rather than buying them -- which is what the vllm1\n"
              "   truncation and length numbers predict.\n",
          rows, lambda k: k[2], levels, a.run)

    print("=" * 70)
    print("3. BY FORM")
    print("=" * 70)
    table("", "   Whether being asked a question rather than given an\n"
              "   instruction changes how fast a belief forms.\n",
          rows, lambda k: k[0], forms, a.run)

    print("=" * 70)
    print("4. BY VERB")
    print("=" * 70)
    table("", "   The vllm1 null, in the time domain. If the verbs differ in\n"
              "   WHEN rather than in how often, the group means would have\n"
              "   missed it.\n",
          rows, lambda k: k[1], verbs, a.run)

    if any(r.get("rule_stated") for r in rows):
        print("=" * 70)
        print("5. TIME TO BELIEF, STATED  (by opponent)")
        print("=" * 70)
        table("", "   The first round the model's own sentence names the right\n"
                  "   strategy and keeps naming it. Scored offline from\n"
                  "   `rule_stated`, so the judgement can be revised without\n"
                  "   rerunning anything.\n",
              rows, lambda k: k[4], opps, a.run, stated=True)

        print("=" * 70)
        print("6. STATED vs DERIVED")
        print("=" * 70)
        print("   stated first   a belief it could not yet act on")
        print("   derived first  pattern matching without a model")
        print("   same round     the belief and the behaviour arrived together\n")
        print(f"   {'opponent':<12}{'both':>7}{'stated<':>9}{'derived<':>10}"
              f"{'same':>7}{'mean gap':>10}")
        for o in opps:
            both, sb, db, same, gaps = 0, 0, 0, 0, []
            for key, cell in cells_of(rows).items():
                if key[4] != o:
                    continue
                d, dc = first_run(cell, a.run)
                s, sc = first_stated(cell, a.run)
                if dc or sc:
                    continue
                both += 1
                gaps.append(d - s)
                if s < d:
                    sb += 1
                elif d < s:
                    db += 1
                else:
                    same += 1
            if both:
                print(f"   {o:<12}{both:>7}{sb:>9}{db:>10}{same:>7}"
                      f"{sum(gaps)/len(gaps):>10.1f}")
        print()

    print("=" * 70)
    print("6b. STATED: SAID AT ALL vs HELD")
    print("=" * 70)
    print("   Table 5 asks when the right sentence STICKS, needing a run of\n"
          f"   {a.run}. A low reached rate there has two very different causes\n"
          "   and this separates them.\n")
    print("   rate       share of all probes whose sentence was right")
    print("   ever       share of cells that said it right at least once")
    print("   longest    median longest consecutive correct run, per cell\n")
    print(f"   {'opponent':<12}{'probes':>8}{'rate':>8}{'ever':>8}"
          f"{'longest':>9}{'held':>7}")
    for o in sorted({r["opponent"] for r in rows}):
        if o not in RULE_RULES:
            continue
        cells = [c for k, c in cells_of(rows).items() if k[4] == o]
        seqs = []
        for c in cells:
            seq = [r for r in sorted(c, key=lambda x: x["round_num"])
                   if r.get("rule_stated")]
            if seq:
                seqs.append([rule_is_right(o, r["rule_stated"]) for r in seq])
        if not seqs:
            continue
        n = sum(len(s) for s in seqs)
        hits = sum(sum(s) for s in seqs)
        ever = sum(1 for s in seqs if any(s))
        runs = []
        for s in seqs:
            best = cur = 0
            for g in s:
                cur = cur + 1 if g else 0
                best = max(best, cur)
            runs.append(best)
        held = sum(1 for r in runs if r >= a.run)
        print(f"   {o:<12}{n:>8,}{100*hits/n:>7.1f}%{100*ever/len(seqs):>7.1f}%"
              f"{statistics.median(runs):>9.0f}{100*held/len(seqs):>6.1f}%")
    print()
    print("   `rate` high with `held` low means the model knows the rule and\n"
          "   keeps abandoning it, which is a different finding from never\n"
          "   having reached it.\n")

    print("=" * 70)
    print("7. THE CURVE  (share of cells with a belief established by round)")
    print("=" * 70)
    print("   A survival curve, read left to right. Two conditions that end\n"
          "   at the same place can get there very differently.\n")
    marks = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    print(f"   {'level':<8}" + "".join(f"{m:>7}" for m in marks))
    for lv in levels:
        got = []
        for key, cell in cells_of(rows).items():
            if key[2] != lv:
                continue
            got.append(first_run(cell, a.run)[0])
        if not got:
            continue
        line = f"   {lv:<8}"
        for m in marks:
            hit = sum(1 for r in got if r is not None and r <= m)
            line += f"{100*hit/len(got):>6.0f}%"
        print(line)
    print()


if __name__ == "__main__":
    raise SystemExit(main())
