# runner.py  (arm: relationderivation)
# One cell = (verb, level, rules, opponent, seed). Every cell reads the SAME
# scripted transcript for its (opponent, seed), so verbs compare round by
# round.
#
# Which path runs is set by config.MODE: the two teacher-forced modes score
# logprobs at the cue, the generating mode asks and parses the answer line.

import config
import database
import game
import prompts

if config.GENERATES:
    import inference
else:
    import scoring


_COLNAMES = {n for n, _ in database.COLUMNS}


# a fresh result row, with every unfilled column left NULL rather than 0
def _row(**kw):
    """Every column starts NULL, so a column this mode does not fill stays
    empty rather than silently defaulting to 0."""
    base = {n: None for n, _ in database.COLUMNS}
    base.update({"arm": config.ARM, "model_kind": config.MODEL_KIND,
                 "parse_failed": 0})
    base.update(kw)
    return base


# plays out one (form, verb, level, rules, opponent, seed) cell, scoring or
# generating depending on config.MODE
def run_cell(form, verb, level, opponent, seed, rules="hidden"):
    total = config.TOTAL_ROUNDS
    rules_shown = (rules == "given")
    script = game.make_transcript(opponent, seed, total, config.NOISE)
    scheduled = set(config.probe_rounds(total))
    records = []

    for i in range(total):
        rnd = i + 1
        # Round 1 has no history to predict from, and on the generating mode
        # the schedule thins out after the belief curve has flattened.
        if rnd not in scheduled:
            continue

        hist = script[:i]
        cur = script[i]
        agent_now, truth = cur["agent"], cur["opponent"]

        built = prompts.build_prediction(hist, level, total, form, verb, agent_now,
                                         rules_shown=rules_shown)

        if config.GENERATES:
            sysmsg, user = built
            got = inference.predict(sysmsg, user, seed * 100_000 + rnd)
            pred = got["prediction"]
            # Everything inference.predict() produced, passed straight
            # through. vllm1 hand-listed these and dropped parse_tier, which
            # is what made the truncation bug need an offline replay to
            # diagnose. Filtering on COLUMNS stores any new key the moment
            # the schema gains it.
            extra = {k: v for k, v in got.items()
                     if k in _COLNAMES and k != "prediction"}
        else:
            probs, cov, top = scoring.move_distribution(built)
            pred = scoring.argmax_move(probs)
            extra = {
                "p_pred": probs[pred], "pred_entropy": scoring.entropy(probs),
                "pred_coverage": cov, "pred_margin": scoring.margin(probs),
                "p_j": probs[game.MOVES[0]], "p_f": probs[game.MOVES[1]],
                "p_m": probs[game.MOVES[2]],
                "top_logprobs": scoring.dump_top(top),
                "attempts": 1, "no_answer_line": 0, "truncated": 0,
            }

        b = game.baselines(hist, agent_now)
        # Recomputed on the history the model actually saw: if the relation is
        # not demonstrated yet, the question is not answerable and the row
        # must not be averaged in.
        facts = len(game.beats_facts_shown(hist))

        records.append(_row(
            form=form, verb=verb,
            level_name=prompts.level_name(verb), task_level=level,
            question=prompts.ask(form, verb, rnd),
            rules=rules, opponent=opponent, seed=seed, round_num=rnd,
            truth=truth, prediction=pred,
            prediction_correct=(int(pred == truth) if pred else None),
            # Scored against what the POLICY says rather than what was played.
            # They differ on counter deviation rounds, and keeping both is what
            # separates "knows the rule" from "got the round right".
            rule_move=cur["rule_move"],
            rule_correct=(int(pred == cur["rule_move"])
                          if pred and cur["rule_move"] else None),
            deviation=cur["deviation"],
            game_outcome=cur["outcome"],
            agent_move=agent_now, beats_facts=facts,
            switched=int(bool(hist) and truth != hist[-1]["opponent"]),
            opponent_move=truth, model_move=agent_now,
            b_opp_last=(int(b["opp_last"] == truth)
                        if b["opp_last"] else None),
            b_own_last=(int(b["own_last"] == truth)
                        if b["own_last"] else None),
            b_modal=int(b["modal"] == truth) if b["modal"] else None,
            b_true_rule=(int(cur["rule_move"] == truth)
                         if cur["rule_move"] else None),
            b_copy_you=int(b["copy_you"] == truth),
            parse_failed=int(pred is None),
            **extra))

    return records
