# config.py  (arm: rulecarry)
#
# This arm hides the beats relation instead of giving it away. Every other
# arm's rules block says "F beats J, M beats F, J beats M" up front; here that
# line is gone, so the model only sees who played what and who won, and has
# to work the relation out for itself before it can predict anything that
# depends on it.
#
# Same question, three ways (set with MODE):
#   MODE=base            base checkpoint, raw continuation, logprobs scored
#   MODE=teacherforcing  instruct checkpoint, prefilled to the cue, logprobs
#   MODE=generating      instruct checkpoint, answers in prose, parsed
#
# base vs teacherforcing isolates the checkpoint; teacherforcing vs generating
# isolates whether the model gets room to write before it commits to an
# answer.

import os


# reads an int env var, falling back to d
def _int(n, d):
    return int(os.environ.get(n, d))


# reads a string env var, falling back to d
def _str(n, d):
    return os.environ.get(n, d)


# reads a float env var, falling back to d
def _float(n, d):
    return float(os.environ.get(n, d))


ARM = "rulecarry"

MODE = _str("MODE", "base")
if MODE not in ("base", "teacherforcing", "generating"):
    raise ValueError(f"MODE must be base|teacherforcing|generating, got {MODE!r}")

MODEL_KIND = "base" if MODE == "base" else "instruct"
GENERATES = MODE == "generating"
SCORES_LOGPROBS = not GENERATES
LABEL_SCHEME = "neutral"

# ── design ───────────────────────────────────────────────────────────────────

TOTAL_ROUNDS = _int("TOTAL_ROUNDS", 100)
PROBE_FROM = _int("PROBE_FROM", 2)

# counter is the same-round responder the original version of this experiment
# used; tft is its lagged twin, and both actually need the relation. mirror,
# cycle and random don't, and sit here as controls for what's solvable
# without it.
OPPONENTS = _str("OPPONENTS", "counter,tft,mirror,cycle,random").split(",")

LEVELS = _str("LEVELS", "L0,L2,L3").split(",")

# Question form only by default. This arm already crosses five opponents
# with two rule conditions, and the form contrast is cheaper to measure
# elsewhere, where a probe costs one token rather than 5000.
FORMS = _str("FORMS", "question,statement").split(",")
FEEDBACK = False

# Dense early, sparse late, and only on the generating mode: a teacher-forced
# probe is one token, so it can afford to probe every round anyway.
PROBE_DENSE_TO = _int("PROBE_DENSE_TO", 30 if GENERATES else 0)
PROBE_SPARSE_EVERY = _int("PROBE_SPARSE_EVERY", 5)


# which rounds actually get probed, given the dense/sparse schedule above
def probe_rounds(total=None):
    total = TOTAL_ROUNDS if total is None else total
    out = []
    for r in range(PROBE_FROM, total + 1):
        if PROBE_DENSE_TO == 0 or r <= PROBE_DENSE_TO:
            out.append(r)
        elif (r - PROBE_DENSE_TO) % PROBE_SPARSE_EVERY == 0:
            out.append(r)
    return out

# Hidden is the actual experiment. `given` puts the one beats line back so a
# low score can't be blamed on the hidden rule rather than the task just
# being hard. It doubles the cell count, so it's opt-in.
# GIVEN by default here, the opposite of relationderivation's default. The
# belief being timed in this arm is about the OPPONENT'S POLICY, and hiding
# the beats relation on top of that would stack a second belief in front of
# it: a model that's worked out the policy but not the relation would look
# like it learned neither. Set RULES=hidden,given to cross them deliberately.
RULES = _str("RULES", "given").split(",")

# One seed for the generating mode, three for the teacher-forced ones -- each
# generating probe is a full generation, the others are one token.
SEEDS = [int(s) for s in _str("SEEDS", "1" if GENERATES else "1,2,3").split(",")]

# Noise applies to `counter` only. That opponent wins every round by
# construction, so without some deviations the outcome lines would only ever
# show "the move that beats yours wins" and the relation would never get
# pinned down from the other side. The other four don't respond to the
# current move and the agent plays randomly, so all three outcomes already
# turn up naturally there.
NOISE = _float("NOISE", 1.0 / 3.0)

# ── vLLM ─────────────────────────────────────────────────────────────────────

VLLM_HOST = _str("VLLM_HOST", "127.0.0.1")
VLLM_PORT = _int("VLLM_PORT", 8000)
VLLM_PYLIBS = _str("VLLM_PYLIBS", "/scratch/mpi_inf/abah00001/vllm_019")
MODEL_PATHS = {"base": "Qwen/Qwen3.5-9B-Base", "instruct": "Qwen/Qwen3.5-9B"}
SERVED_NAMES = {"base": "qwen35-9b-base", "instruct": "qwen35-9b"}
VLLM_MODEL_PATH = MODEL_PATHS[MODEL_KIND]
VLLM_SERVED_NAME = SERVED_NAMES[MODEL_KIND]

# This arm's history runs four lines per round instead of three, so 100
# rounds is roughly 1900 tokens. Add MAX_NEW_TOKENS on top and 8192 would be
# too tight.
VLLM_MAX_MODEL_LEN = _int("VLLM_MAX_MODEL_LEN", 16384)
VLLM_GPU_MEM_UTIL = _float("VLLM_GPU_MEM_UTIL", 0.85)
VLLM_STARTUP_TIMEOUT_S = _int("VLLM_STARTUP_TIMEOUT_S", 1200)
VLLM_MAX_LOGPROBS = _int("VLLM_MAX_LOGPROBS", 20)
TOP_LOGPROBS = VLLM_MAX_LOGPROBS

# ── sampling (generating mode) ───────────────────────────────────────────────

ENABLE_THINKING = _int("ENABLE_THINKING", 0) == 1
TEMPERATURE = _float("TEMPERATURE", 0.7)
TOP_P = _float("TOP_P", 0.8)
TOP_K = _int("TOP_K", 20)
MIN_P = _float("MIN_P", 0.0)
PRESENCE_PENALTY = _float("PRESENCE_PENALTY", 1.5)
MAX_NEW_TOKENS = _int("MAX_NEW_TOKENS", 5000)
# Budget for the forced exit. Kept small on purpose -- the ask is for ten
# words, and a large budget here would just reproduce the problem it exists
# to solve.
EXIT_MAX_TOKENS = _int("EXIT_MAX_TOKENS", 32)

# ── the rule probe ───────────────────────────────────────────────────────────
#
# Asks the model every round to state what it currently believes the
# opponent is doing. That gives a time-to-belief figure directly instead of
# inferring it from a run of correct predictions, and the two can then be
# checked against each other: a model whose predictions converge before its
# stated rule does is pattern-matching; one whose stated rule converges
# first is holding a belief it can't yet act on.
#
# Generating mode only -- a teacher-forced probe is a single token and can't
# produce a sentence, so those modes lean on the derived measure alone,
# which belief.py computes for every mode anyway.
#
# The answer is stored VERBATIM in `rule_stated` and scored offline by
# keyword. That's deliberate: the scoring logic is the part most likely to
# need tweaking, and doing it offline means changing it never costs GPU
# time.
RULE_PROBE = _int("RULE_PROBE", 1 if GENERATES else 0) == 1

# A belief counts as established at the first round that begins a run of
# this many consecutive rule-correct predictions. Five is long enough that
# chance (1/3) gives a 0.4% false positive per round, and short enough to
# resolve inside a 100-round game.
BELIEF_RUN = _int("BELIEF_RUN", 5)

RETRY_MAX = _int("RETRY_MAX", 5)
REQUIRE_ANSWER_LINE = _int("REQUIRE_ANSWER_LINE", 1) == 1

MAX_CONCURRENT = _int("MAX_CONCURRENT", 4 if GENERATES else 24)
REQUEST_TIMEOUT_S = _int("REQUEST_TIMEOUT_S", 300)

# ── output ───────────────────────────────────────────────────────────────────

RESULTS_DIR = _str("RESULTS_DIR",
                   f"/scratch/mpi_inf/abah00001/exppragvllm2_results/"
                   f"{ARM}/{MODE}")
# One directory per mode. In vllm1 all three modes wrote into the same
# folder, and since read.py globs *_run*.db, a single command ended up
# averaging a base checkpoint, a teacher-forced instruct and a generating
# instruct into the same table. Worse, the paired test keyed on
# (seed, round_num): rows collided, the reference dict silently kept
# whichever loaded last, and it reported d = +25.0 with t = 11.2 where the
# actual group means differed by 4. Separate directories make that mistake
# impossible instead of just documented.
FINAL_COPY_DIR = _str("FINAL_COPY_DIR",
                      f"/home/abah00001/expprag/exppragvllm2/"
                      f"results/{ARM}/{MODE}")


# the filename prefix every database for this arm/mode shares
def db_prefix():
    return f"{ARM}_{MODE}_{LABEL_SCHEME}"
