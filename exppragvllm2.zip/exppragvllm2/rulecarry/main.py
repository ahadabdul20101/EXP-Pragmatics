#!/usr/bin/env python3
# main.py  (arm: relationderivation)
#
#   python3 main.py --self-test                     no GPU, no server
#   python3 main.py --dry-run --yes --rounds 15
#   MODE=base           python3 serve.py --yes --opponents counter --tag counter
#   MODE=generating     python3 serve.py --yes --opponents tft     --tag tft

import argparse
import datetime
import os
import shutil
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

import config
import database
import game
import prompts
import runner


# renders a built prompt (chat pair or plain string) as one printable block
def _as_text(built):
    return built if isinstance(built, str) else f"[system]\n{built[0]}\n\n[user]\n{built[1]}"


# ── self-test ────────────────────────────────────────────────────────────────

# every (form, verb) pair this arm actually runs
def _conditions():
    """Every (form, verb) pair this arm actually runs."""
    return prompts.conditions(config.FORMS)


# prints the prompt, the design, and a batch of consistency checks; no GPU
def self_test():
    ok = True
    script = game.make_transcript("counter", 1, 6, config.NOISE)
    hist, agent_now = script[:3], script[3]["agent"]

    print("=" * 74)
    print(f"1. THE PROMPT, in full   [MODE {config.MODE} / {config.MODEL_KIND}]")
    print("=" * 74)
    _shown = config.RULES[0] == "given"
    print(_as_text(prompts.build_prediction(hist, "L0", config.TOTAL_ROUNDS,
                                            "question", "predict", agent_now,
                                            rules_shown=_shown)))
    print(f"^^^ RULES={config.RULES[0]}: the beats relation is "
          f"{'stated in the rules block' if _shown else 'nowhere in this document'}\n")

    print("=" * 74)
    print("2. The line that varies")
    print("=" * 74)
    for form, verb in _conditions():
        print(f"   {form:<12} {prompts.level_name(verb):8s} {verb:11s} "
              f"{prompts.ask(form, verb, 42)}")
    print("\n   task lines:")
    for lv in config.LEVELS:
        print(f"   {lv:8s} ({prompts.LEVEL_DESCRIPTIONS[lv]}) "
              f"{prompts.TASK_LINE[lv] or '(nothing)'}")
    nest, why = prompts.levels_nest()
    print(f"   {'PASS' if nest else 'FAIL'}  L3 decomposes into L1 + L2"
          f"{'' if nest else '  -- ' + why}")
    ok = ok and nest
    print()

    print("=" * 74)
    print("3. Is the rule actually hidden, and does `given` differ by one line?")
    print("=" * 74)
    for lv in config.LEVELS:
        hid = prompts.rule_is_hidden(hist, lv, config.TOTAL_ROUNDS, agent_now)
        print(f"   {'PASS' if hid else 'FAIL'}  {lv}: the hidden prompt never "
              f"says what beats what")
        ok = ok and hid
        one, diff = prompts.hidden_given_differ_by_one_line(
            hist, lv, config.TOTAL_ROUNDS, agent_now)
        print(f"   {'PASS' if one else 'FAIL'}  {lv}: hidden and given differ "
              f"by exactly the beats line{'' if one else f' -- got {diff}'}")
        ok = ok and one
    print()

    print("=" * 74)
    print("4. Geometry")
    print("=" * 74)
    for lv in config.LEVELS:
        for rs in (False, True):
            same, why = prompts.only_the_ask_differs(
                hist, lv, config.TOTAL_ROUNDS, agent_now, rs, config.FORMS)
            tag = "given " if rs else "hidden"
            print(f"   {'PASS' if same else 'FAIL'}  {lv} {tag}: all "
                  f"{len(_conditions())} conditions differ only in the ask"
                  f"{'' if same else '  -- ' + why}")
            ok = ok and same
    one, why = prompts.ask_is_one_line(hist, "L0", config.TOTAL_ROUNDS,
                                       agent_now, config.FORMS)
    print(f"   {'PASS' if one else 'FAIL'}  every ask is one line"
          f"{'' if one else '  -- ' + why}")
    ok = ok and one
    clean, why = prompts.nothing_to_copy(hist, "L0", config.TOTAL_ROUNDS,
                                         agent_now)
    print(f"   {'PASS' if clean else 'FAIL'}  nothing to copy beside the cue"
          f"{'' if clean else '  -- ' + why}")
    ok = ok and clean
    print()

    print("=" * 74)
    print("5. Is the relation derivable, and when?")
    print("=" * 74)
    print("   All three beats facts must appear, or the question is not")
    print("   answerable. beats_facts is stored per row and the `clean` view")
    print("   drops anything below three.\n")
    print(f"   {'opponent':<9} {'seed':<5} {'all 3 by round':>15} "
          f"{'outcomes (opp/you/tie)':>26}")
    for opp in config.OPPONENTS:
        for seed in config.SEEDS:
            t = game.make_transcript(opp, seed, config.TOTAL_ROUNDS,
                                     config.NOISE)
            first = next((i for i in range(1, len(t) + 1)
                          if len(game.beats_facts_shown(t[:i])) == 3), None)
            c = Counter(r["outcome"] for r in t)
            mix = (f"{100*c['opponent']/len(t):4.1f}/"
                   f"{100*c['you']/len(t):4.1f}/{100*c['tie']/len(t):4.1f}")
            flag = "" if first else "   <- NEVER, cell unusable"
            print(f"   {opp:<9} {seed:<5} {str(first):>15} {mix:>26}{flag}")
            ok = ok and first is not None
    print()

    print("=" * 74)
    print("6. Do the opponents do what they claim?")
    print("=" * 74)
    for opp in config.OPPONENTS:
        t = game.make_transcript(opp, 1, 8, config.NOISE)
        print(f"   {opp:<9} you {[r['agent'] for r in t]}")
        print(f"   {'':<9} opp {[r['opponent'] for r in t]}")
        if opp == "counter":
            good = all(r["opponent"] == game.BEATS[r["agent"]]
                       for r in t if not r["deviation"])
            print(f"   {'':<9} {'PASS' if good else 'FAIL'}  on rule rounds "
                  f"plays what beats your CURRENT move")
            ok = ok and good
        elif opp == "tft":
            good = all(t[i]["opponent"] == game.BEATS[t[i - 1]["agent"]]
                       for i in range(1, len(t)))
            print(f"   {'':<9} {'PASS' if good else 'FAIL'}  plays what beats "
                  f"your PREVIOUS move")
            ok = ok and good
        elif opp == "mirror":
            good = all(t[i]["opponent"] == t[i - 1]["agent"]
                       for i in range(1, len(t)))
            print(f"   {'':<9} {'PASS' if good else 'FAIL'}  copies your "
                  f"previous move")
            ok = ok and good
    print()

    rounds = config.probe_rounds(config.TOTAL_ROUNDS)
    cells = (len(_conditions()) * len(config.LEVELS) * len(config.OPPONENTS)
             * len(config.SEEDS) * len(config.RULES))
    probes = cells * len(rounds)
    print(f"   {len(_conditions())} conditions ({len(config.FORMS)} forms) "
          f"x {len(config.LEVELS)} levels x {len(config.OPPONENTS)} opponents "
          f"x {len(config.SEEDS)} seeds x {len(config.RULES)} rules")
    print(f"   {cells} cells, {len(rounds)} probe rounds each "
          f"(rounds {rounds[0]}..{rounds[-1]})")
    print(f"   {probes} probes "
          f"({probes // max(1, len(config.OPPONENTS))} per opponent job)\n")

    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


# ── run ──────────────────────────────────────────────────────────────────────

# reads the command-line flags, defaulting each one from config
def parse_args():
    p = argparse.ArgumentParser(description="exppragvllm relationderivation")
    p.add_argument("--forms", nargs="+", default=config.FORMS)
    p.add_argument("--verbs", nargs="+", default=None,
                   help="restrict to these verbs; default is every "
                        "verb each form defines")
    p.add_argument("--levels", nargs="+", default=config.LEVELS)
    p.add_argument("--opponents", nargs="+", default=config.OPPONENTS)
    p.add_argument("--rules", nargs="+", default=config.RULES)
    p.add_argument("--seeds", nargs="+", type=int, default=config.SEEDS)
    p.add_argument("--rounds", type=int, default=config.TOTAL_ROUNDS)
    p.add_argument("--tag", default=None)
    p.add_argument("--workers", type=int, default=config.MAX_CONCURRENT)
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--yes", action="store_true")
    return p.parse_args()


# builds the cell list, runs it through the worker pool, and writes results
def main():
    args = parse_args()
    if args.self_test:
        return self_test()
    if args.dry_run:
        if config.GENERATES:
            import inference
            inference.use_stub()
        else:
            import scoring
            scoring.use_stub()

    config.TOTAL_ROUNDS = args.rounds
    conds = [(f, v) for f, v in prompts.conditions(args.forms)
             if args.verbs is None or v in args.verbs]
    cells = [(f, v, l, o, s, r) for (f, v) in conds for l in args.levels
             for o in args.opponents for s in args.seeds for r in args.rules]
    tag = args.tag or (args.opponents[0] if len(args.opponents) == 1 else "main")

    db_path = database.next_path(tag)
    conn = database.connect(db_path)
    database.write_meta(conn, {
        "status": "running",
        "started": datetime.datetime.now().isoformat(timespec="seconds"),
        "arm": config.ARM, "mode": config.MODE,
        "model_kind": config.MODEL_KIND, "model": config.VLLM_MODEL_PATH,
        "total_rounds": args.rounds, "probe_from": config.PROBE_FROM,
        "noise": config.NOISE,
        "opponents": ",".join(args.opponents), "levels": ",".join(args.levels),
        "rules": ",".join(args.rules),
        "forms": ",".join(args.forms),
        "conditions": len(conds),
        "probe_dense_to": config.PROBE_DENSE_TO,
        "probe_sparse_every": config.PROBE_SPARSE_EVERY,
        "seeds": ",".join(map(str, args.seeds)),
        "max_new_tokens": config.MAX_NEW_TOKENS,
        "enable_thinking": config.ENABLE_THINKING,
        "presence_penalty": config.PRESENCE_PENALTY,
        "require_answer_line": config.REQUIRE_ANSWER_LINE,
        "generates": config.GENERATES,
        "dry_run": args.dry_run})

    print("=" * 78)
    print(f"  exppragvllm — relationderivation / {config.MODE}")
    print("=" * 78)
    print(f"  {config.VLLM_MODEL_PATH}{'  [DRY RUN]' if args.dry_run else ''}")
    print(f"  Forms:     {args.forms}")
    print(f"  Conditions:{len(conds):>3}   Levels: {args.levels}   "
          f"Rules: {args.rules}")
    print(f"  Opponents: {args.opponents}   Seeds: {args.seeds}")
    print(f"  Rounds:    {args.rounds}   Cells: {len(cells)}")
    print(f"  Database:  {db_path}")
    print("=" * 78, flush=True)

    if not args.yes and not args.dry_run:
        if input("  Proceed? [y/N] ").strip().lower() not in ("y", "yes"):
            sys.exit(0)

    done, rows = 0, []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futs = {pool.submit(runner.run_cell, f, v, l, o, s, r):
                (f, v, l, o, s, r)
                for (f, v, l, o, s, r) in cells}
        for fut in as_completed(futs):
            f, v, l, o, s, r = futs[fut]
            got = fut.result()
            database.insert(conn, got)
            rows += got
            done += 1
            rc = [x["rule_correct"] for x in got
                  if x["rule_correct"] is not None]
            acc = 100 * sum(rc) / len(rc) if rc else 0.0
            print(f"  [{done}/{len(cells)}] {o:<8} {l:<3} {r:<6} {f:<11} {v:<11} s{s}  "
                  f"rule {acc:5.1f}%", flush=True)

    database.write_meta(conn, {
        "status": "complete",
        "finished": datetime.datetime.now().isoformat(timespec="seconds"),
        "rows": database.count(conn)})
    summary(rows, args, conds)
    conn.close()

    if config.FINAL_COPY_DIR:
        os.makedirs(config.FINAL_COPY_DIR, exist_ok=True)
        shutil.copy2(db_path, config.FINAL_COPY_DIR)
        print(f"\n  Copied to {config.FINAL_COPY_DIR}")
    return 0


# prints the rule% / move% accuracy table, the counter split, and generation
# or coverage health depending on the mode
def summary(rows, args, conds):
    # the mean of `key` over rows that have it, as a percentage
    def pct(rs, key):
        v = [r[key] for r in rs if r.get(key) is not None]
        return 100 * sum(v) / len(v) if v else None

    # right-aligned one-decimal formatting, with an em dash for missing values
    def f(v, w=6):
        return f"{v:{w}.1f}" if isinstance(v, (int, float)) else f"{'—':>{w}}"

    usable = [r for r in rows
              if r["prediction"] is not None and not (r["no_answer_line"] or 0)
              and (r["beats_facts"] or 3) >= 3]

    print("\n" + "=" * 96)
    print(f"  relationderivation / {config.MODE}")
    print("=" * 96)
    print("\n  rule%  is scored against what the opponent's POLICY says.")
    print("  move%  is scored against what it actually played.")
    print("  They differ only on counter deviation rounds, where the rule's")
    print("  answer is wrong by construction -- so a model that has learned")
    print("  the rule should score high on rule% and LOW on deviation rounds.")
    print("  Low there is a success: it means the rule is being applied")
    print("  rather than hedged.\n")

    for o in args.opponents:
        print(f"  {o}")
        print(f"    {'form':<12} {'verb':<11} {'lvl':<4} {'rules':<7} "
              f"{'rule%':>6} {'move%':>6} {'copy_you':>9}   {'answers':<20}")
        for (fm, v) in conds:
            for l in args.levels:
                for rl in args.rules:
                    rs = [r for r in usable if r["opponent"] == o
                          and r["form"] == fm and r["verb"] == v
                          and r["task_level"] == l and r["rules"] == rl]
                    if not rs:
                        continue
                    c = Counter(r["prediction"] for r in rs)
                    tot = len(rs) or 1
                    ans = " ".join(f"{m}:{100*c[m]/tot:4.1f}%"
                                   for m in game.MOVES)
                    print(f"    {v:<11} {l:<4} {rl:<7} "
                          f"{f(pct(rs,'rule_correct'))} "
                          f"{f(pct(rs,'prediction_correct'))} "
                          f"{f(pct(rs,'b_copy_you'), 9)}   {ans:<20}")
        print()

    print("  SPLIT BY ROUND TYPE (move%), counter only -- the others never "
          "deviate")
    ctr = [r for r in usable if r["opponent"] == "counter"]
    if ctr:
        for dev, lab in ((0, "rule rounds"), (1, "deviation")):
            sub = [r for r in ctr if r["deviation"] == dev]
            print(f"    {lab:<14}{f(pct(sub,'prediction_correct'))}   "
                  f"(n={len(sub)})")

    short = [r for r in rows if (r["beats_facts"] or 3) < 3]
    print(f"\n  Rows where the relation was not yet demonstrated: {len(short)}"
          f" of {len(rows)} -- excluded by `clean`.")

    if config.GENERATES:
        nal = [r for r in rows if r["no_answer_line"]]
        tr = [r for r in rows if r["truncated"]]
        print(f"\n  GENERATION HEALTH")
        print(f"    no answer line: {len(nal)} of {len(rows)} "
              f"({100*len(nal)/max(1,len(rows)):.1f}%)")
        print(f"    truncated:      {len(tr)} of {len(rows)} "
              f"({100*len(tr)/max(1,len(rows)):.1f}%)  "
              f"cap {config.MAX_NEW_TOKENS}")
    else:
        low = [r for r in rows if (r.get("pred_coverage") or 1) < 0.90]
        print(f"\n  Coverage below 0.90: {len(low)} of {len(rows)} "
              f"({100*len(low)/max(1,len(rows)):.1f}%)")
    print("=" * 96)


if __name__ == "__main__":
    sys.exit(main() or 0)
