#!/usr/bin/env python3
# coverage.py -- the coverage study, relationderivation edition.
# Works on MODE=base and MODE=teacherforcing; the generating mode stores no
# probabilities, so there's nothing for it to read here.
#
#   python3 coverage.py --dir ~/expprag/exppragvllm/results/relationderivation
#   python3 coverage.py --dir ... --band 10 --opponent cycle
#
# Why this exists: notemp2's base path ran at ~0.99 coverage with the
# answer ratio matching the true distribution exactly. Later harnesses on
# the same geometry read 0.67-0.86, which put most rows under the usability
# floor and left a third of the probability mass unaccounted for. Guessing
# where it went isn't good enough to report.
#
# The question here is narrower and answerable: does the verb move
# coverage, and does that change as the history grows? Both are read
# straight from the database, since every row stores the top-k tokens with
# their logprobs -- so no extra GPU job is needed to say where the non-move
# mass sits.
#
# Four tables:
#   1  coverage by verb x round band          does the verb move it, and when
#   2  coverage by verb, pooled, with spread  how big is the verb effect
#   3  where the non-move mass goes           whitespace / table / other
#   4  answer ratio and entropy by verb       the check accuracy can't do
#
# Reading table 3:
#   whitespace dominates  benign. The model knows the answer and wants a
#                         separator first; the J/F/M ranking is untouched,
#                         so accuracy stands and the floor can be lowered
#                         with this output as the justification.
#   'Round' or a digit    the model is continuing the table rather than
#                         answering. Move the cue; don't lower the floor.
#   anything else         it's answering a different question entirely.

import argparse
import glob
import json
import os
import sqlite3
from collections import Counter, defaultdict

MOVES = ("J", "F", "M")
LEVEL_ORDER = ["high", "mid", "low", "neutral", "task", "none"]


# loads every row with a coverage figure from the given database files
def load(paths):
    rows = []
    for p in paths:
        conn = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            rows += [dict(r) for r in conn.execute(
                "SELECT * FROM rounds WHERE pred_coverage IS NOT NULL")]
        except sqlite3.Error:
            pass
        conn.close()
    return rows


# arithmetic mean, ignoring Nones; None if there's nothing left
def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


# a mean formatted, or an em dash when the column was empty or NULL.
# mean() returns None for an all-NULL column, and that's not an error:
# `random` has no policy, a generating mode scores no logprobs, and an
# older database may lack a column entirely. Formatting that None directly
# is what took down read.py on the first real database it saw.
def num(m, w=9, dp=3, pct=False):
    if m is None:
        return f"{chr(8212):>{w}}"
    return f"{100 * m:>{w}.{dp}f}" if pct else f"{m:>{w}.{dp}f}"


# the verbs present, ordered by epistemic level then name. An unknown or
# missing level sorts last rather than raising -- a verb added to
# prompts.VERBS with a new level name used to take down table 1 of every
# reader with `None is not in list`.
def verbs_of(rows):
    seen = {}
    for r in rows:
        seen.setdefault(r["verb"], r["level_name"])

    def rank(v):
        lv = seen[v]
        return (LEVEL_ORDER.index(lv) if lv in LEVEL_ORDER
                else len(LEVEL_ORDER), v)

    return sorted(seen, key=rank)


# the opponents present, in a fixed display order with any extras appended
def opps_of(rows):
    order = ["counter", "tft", "mirror", "cycle", "random"]
    got = {r["opponent"] for r in rows}
    return [o for o in order if o in got] + sorted(got - set(order))


# printable form of a token, with whitespace named rather than escaped.
# repr() turns a newline into '\n', which is readable, but a plain space
# and a non-breaking space look identical -- naming the class is the whole
# point.
def show_token(tok):
    if tok == "":
        return "<empty>"
    if tok.strip() == "":
        kinds = {" ": "space", "\n": "newline", "\t": "tab", "\r": "return"}
        return "<" + "+".join(kinds.get(c, f"U+{ord(c):04X}") for c in tok) + ">"
    return repr(tok)


# which of the three conclusions in the header this token belongs to
def bucket(tok):
    if tok.strip() == "":
        return "whitespace"
    s = tok.strip()
    if s.isdigit() or s.lower().startswith("round"):
        return "table"
    return "other"


def is_move(tok):
    t = tok.strip().lower()
    return bool(t) and any(m.lower().startswith(t) for m in MOVES)


# ── 1: the table the study is for ────────────────────────────────────────────

def t1_bands(rows, band):
    print(f"\n1. COVERAGE BY VERB x {band}-ROUND BAND")
    print("   Coverage is the mass on the move labels at the answer position.")
    print("   A flat row means the verb's effect on coverage does not depend")
    print("   on how much history there is; a rising row means the document")
    print("   gets easier to complete as it grows.\n")
    lo = min(r["round_num"] for r in rows)
    hi = max(r["round_num"] for r in rows)
    edges = [(s, min(s + band - 1, hi)) for s in range(lo, hi + 1, band)]
    for o in opps_of(rows):
        sub = [r for r in rows if r["opponent"] == o]
        if not sub:
            continue
        print(f"   {o}")
        print(f"      {'verb':<11}" + "".join(f"{f'{a}-{b}':>9}"
                                              for a, b in edges)
              + f"{'all':>9}")
        g = defaultdict(list)
        for r in sub:
            g[r["verb"]].append(r)
        for v in verbs_of(sub):
            cells = ""
            for a, b in edges:
                m = mean([r["pred_coverage"] for r in g[v]
                          if a <= r["round_num"] <= b])
                cells += f"{m:>9.3f}" if m is not None else f"{'—':>9}"
            allm = mean([r["pred_coverage"] for r in g[v]])
            print(f"      {v:<11}{cells}{allm:>9.3f}")
        print()


def t2_pooled(rows):
    print("2. COVERAGE BY VERB, pooled over opponents")
    print("   The spread is the size of the verb effect on coverage. If it is")
    print("   larger than the spread across opponents, coverage is tracking")
    print("   the QUESTION rather than the task -- which would make it a")
    print("   property of the wording, not of the prediction problem.\n")
    g = defaultdict(list)
    for r in rows:
        g[r["verb"]].append(r)
    print(f"      {'verb':<11} {'level':<8} {'coverage':>9} {'entropy':>9} "
          f"{'below .90':>10} {'n':>7}   question")
    per = []
    for v in verbs_of(rows):
        rs = g[v]
        cov = mean([r["pred_coverage"] for r in rs])
        per.append(cov)
        ent = mean([r["pred_entropy"] for r in rs])
        low = 100 * sum(1 for r in rs if (r["pred_coverage"] or 1) < 0.90) / len(rs)
        q = (rs[0]["question"] or "")[:44]
        print(f"      {v:<11} {(rs[0]['level_name'] or '?'):<8} "
              f"{num(cov)} {num(ent)} {low:>9.1f}% {len(rs):>7}   {q}")
    og = defaultdict(list)
    for r in rows:
        og[r["opponent"]].append(r["pred_coverage"])
    opp_spread = (max(mean(v) for v in og.values())
                  - min(mean(v) for v in og.values()))
    print(f"\n      spread across verbs     {max(per) - min(per):.3f}")
    print(f"      spread across opponents {opp_spread:.3f}")
    print("      -> " + ("the VERB moves coverage more than the task does"
                         if max(per) - min(per) > opp_spread
                         else "the task moves coverage more than the verb does"))
    print()


# ── 3: where the missing mass went ───────────────────────────────────────────

def t3_mass(rows, k):
    have = [r for r in rows if r["top_logprobs"]]
    if not have:
        print("3. WHERE THE NON-MOVE MASS GOES\n   no top_logprobs stored\n")
        return
    print("3. WHERE THE NON-MOVE MASS GOES")
    print("   Read straight from the stored top-k, so this needs no extra GPU")
    print("   job. Buckets are mean probability per row.\n")
    g = defaultdict(list)
    for r in have:
        g[r["verb"]].append(r)
    print(f"      {'verb':<11} {'coverage':>9} {'whitespace':>11} {'table':>8} "
          f"{'other':>8}")
    totals = Counter()
    tokens = defaultdict(lambda: defaultdict(float))
    for v in verbs_of(have):
        rs = g[v]
        acc = Counter()
        for r in rs:
            try:
                top = json.loads(r["top_logprobs"])
            except (TypeError, ValueError):
                continue
            import math as _m
            for tok, lp in top:
                if is_move(tok):
                    continue
                p = _m.exp(lp)
                acc[bucket(tok)] += p
                tokens[v][show_token(tok)] += p
        n = len(rs) or 1
        for b in ("whitespace", "table", "other"):
            totals[b] += acc[b]
        print(f"      {v:<11} {num(mean([r['pred_coverage'] for r in rs]))} "
              f"{acc['whitespace']/n:>11.3f} {acc['table']/n:>8.3f} "
              f"{acc['other']/n:>8.3f}")

    print(f"\n      biggest non-move tokens per verb (mean probability)")
    for v in verbs_of(have):
        n = len(g[v]) or 1
        best = sorted(tokens[v].items(), key=lambda kv: -kv[1])[:k]
        print(f"        {v:<11}" + "  ".join(f"{nm} {p/n:.3f}"
                                             for nm, p in best))

    if sum(totals.values()) <= 0:
        print("\n      The stored top-k is entirely move tokens. The missing")
        print("      mass sits below rank "
              f"{rows[0].get('top_logprobs') and 'k'} -- raise TOP_LOGPROBS.")
        return
    biggest = max(totals, key=totals.get)
    print()
    if biggest == "whitespace":
        lowest = min(mean([r["pred_coverage"] for r in g[v]])
                     for v in verbs_of(have))
        print("      Dominant bucket: WHITESPACE. The model knows the answer")
        print("      and wants a separator first, so the J/F/M ranking is")
        print("      unaffected and accuracy stands. A usability floor just")
        print(f"      under the lowest verb ({lowest:.3f}) is defensible, and")
        print("      this table is the justification.")
    elif biggest == "table":
        print("      Dominant bucket: TABLE. The model is continuing the round")
        print("      listing rather than answering. Lowering the floor would")
        print("      admit rows that are not measuring prediction -- move the")
        print("      cue instead.")
    else:
        print("      Dominant bucket: OTHER. It is answering something else.")
        print("      Read the per-verb tokens above before changing anything.")
    print()


def t4_ratio(rows):
    print("4. ANSWER RATIO AND ENTROPY by verb")
    print("   cycle and random play each move equally often, so their answers")
    print("   must read near 33/33/33. notemp2's base path came out exactly")
    print("   10/10/10 on 30 cycle probes, which is what a clean cue looks")
    print("   like. Entropy is in bits: 0 is certain, 1.585 is no opinion.\n")
    for o in opps_of(rows):
        sub = [r for r in rows if r["opponent"] == o]
        if not sub:
            continue
        print(f"   {o}")
        g = defaultdict(list)
        for r in sub:
            g[r["verb"]].append(r)
        print(f"      {'verb':<11}" + "".join(f"{'p('+m+')':>9}" for m in MOVES)
              + f"{'entropy':>9}{'margin':>9}")
        for v in verbs_of(sub):
            rs = g[v]
            c = Counter(r["prediction"] for r in rs if r["prediction"])
            tot = sum(c.values()) or 1
            print(f"      {v:<11}"
                  + "".join(f"{100*c[m]/tot:>9.1f}" for m in MOVES)
                  + num(mean([r['pred_entropy'] for r in rs]))
                  + num(mean([r['pred_margin'] for r in rs])))
        print()


def main():
    ap = argparse.ArgumentParser(description="coverage study")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--band", type=int, default=10,
                    help="round-band width (default 10)")
    ap.add_argument("--opponent", nargs="+", default=None)
    ap.add_argument("--level", default=None, help="restrict to L0 or L3")
    ap.add_argument("--top", type=int, default=4,
                    help="non-move tokens listed per verb")
    args = ap.parse_args()

    paths = sorted(glob.glob(os.path.join(args.dir, "*_run*.db")))
    if not paths:
        print(f"no databases in {args.dir}")
        return 1
    rows = load(paths)
    if args.opponent:
        rows = [r for r in rows if r["opponent"] in args.opponent]
    if args.level:
        rows = [r for r in rows if r["task_level"] == args.level]
    if not rows:
        print("no teacher-forced rows matched "
              "(this study needs base or teacherforcing)")
        return 1

    print(f"{len(rows)} scored rows from {len(paths)} database(s)")
    print(f"arms: {sorted({(r['arm'], r['model_kind']) for r in rows})}")
    print(f"band width: {args.band} rounds")

    t1_bands(rows, args.band)
    t2_pooled(rows)
    t3_mass(rows, args.top)
    t4_ratio(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
