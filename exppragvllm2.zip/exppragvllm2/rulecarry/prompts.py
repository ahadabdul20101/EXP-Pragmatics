

import config
import game

FORMS = ("question", "statement", "statement_n", "taskverb")

FRAMES = {
    "question":    "What do you {verb} the opponent will play in this round?",
    "statement":   "{Verb} the opponent's move in this round.",
    "statement_n": "{Verb} the opponent's move in round {n}.",
    "taskverb":    "Your task is to {verb} the opponent's move in this round.",
}

VERBS = {
    "predict":    "high",
    "forecast":   "high",
    "infer":      "high",
    "expect":     "mid",
    "anticipate": "mid",
    "estimate":   "mid",
    "guess":      "low",
    "suppose":    "low",
    "imagine":    "low",
    "say":        "neutral",
}

EPISTEMIC = tuple(v for v, lvl in VERBS.items() if lvl != "neutral")

NO_VERB = "Which move will the opponent play in this round?"


# every (form, verb) pair the requested forms produce
def conditions(forms=None):
    forms = FORMS if forms is None else forms
    out = []
    if "question" in forms:
        out += [("question", v) for v in VERBS]
        out.append(("question", "none"))
    for form in forms:
        if form == "question":
            continue
        out += [(form, v) for v in EPISTEMIC]
    return out


# the one line that varies; everything else in the prompt is fixed
def ask(form, verb, rnd):
    if form not in FRAMES:
        raise ValueError(f"unknown form {form!r}")
    if verb == "none":
        if form != "question":
            raise ValueError("the frameless anchor exists only as a question")
        return NO_VERB
    if verb not in VERBS:
        raise ValueError(f"unknown verb {verb!r}")
    return FRAMES[form].format(verb=verb, Verb=verb.capitalize(), n=rnd)


# the verb's epistemic level, or "none" for the frameless anchor
def level_name(verb):
    return "none" if verb == "none" else VERBS[verb]


# the longest ask line across every condition, for sizing checks
def longest_ask(rnd=100):
    return max((ask(f, v, rnd) for f, v in conditions()), key=len)


# ── task framing ─────────────────────────────────────────────────────────────
#
# Same split as the other arms.

SEARCH = ("Your task is to find the pattern in the history and use it to "
          "predict.")
POINTER = "The opponent's move depends on what you played."

TASK_LINE = {
    "L0": "",
    "L1": SEARCH,
    "L2": POINTER,
    "L3": f"{SEARCH} {POINTER}",
}

LEVEL_DESCRIPTIONS = {
    "L0": "no framing",
    "L1": "search only",
    "L2": "pointer only",
    "L3": "search + pointer",
}

IM_START = "<|im_start|>"
IM_END = "<|im_end|>"


# the task line for this level, with its trailing newline if non-empty
def _task(level):
    if level not in TASK_LINE:
        raise ValueError(f"unknown level {level!r}")
    return f"{TASK_LINE[level]}\n" if TASK_LINE[level] else ""


RULE_LABEL = "Rule:"


# the belief probe
def rule_probe():
    return (f"Also state what you currently believe the opponent's strategy "
            f"is, on its own line, formatted exactly like:\n"
            f"{RULE_LABEL} <one short sentence>")


# instruct-generating only
def spec():
    parts = []
    if config.RULE_PROBE:
        parts.append(rule_probe())
    parts.append(f"Your answer MUST end with a line formatted exactly like:\n"
                 f"{game.OPPONENT_LABEL} <one of the moves>")
    return "\n".join(parts)


# sent only when the first call hit the token cap. vllm1's generating mode

def forced_exit_user():
    return ("Stop reasoning now. In ten words or fewer, give only your final "
            f"answer, formatted exactly like:\n"
            f"{game.OPPONENT_LABEL} <one of the moves>")


def body(hist, level, total_rounds, form, verb, agent_now, first_round=1):
    rnd = first_round + len(hist)
    return (f"{game.format_history(hist, first_round)}\n\n"
            f"{_task(level)}"
            f"Round {rnd}\n"
            f"{game.AGENT_LABEL} {agent_now}\n"
            f"{ask(form, verb, rnd)}")


# dispatches on MODEL_KIND and GENERATES:
#   base            raw continuation ending at the bare cue
#   teacher-forced  ChatML with the assistant turn prefilled to the cue
#   generating      ChatML via the chat endpoint, returns (system, user)
def build_prediction(hist, level, total_rounds, form, verb, agent_now,
                     rules_shown=False, first_round=1):
    rules = game.rules_block(total_rounds, rules_shown)
    core = body(hist, level, total_rounds, form, verb, agent_now, first_round)

    if config.MODEL_KIND == "base":
        return f"{rules}\n\n{core}\n\n{game.OPPONENT_LABEL}"

    if config.GENERATES:
        return rules, f"{core}\n{spec()}"

    return (f"{IM_START}system\n{rules}{IM_END}\n"
            f"{IM_START}user\n{core}{IM_END}\n"
            f"{IM_START}assistant\n{game.OPPONENT_LABEL}")


# ── guards ──

# joins a (system, user) pair into one string for comparison; a plain
# string (base arm) passes through unchanged
def _as_text(built):
    return built if isinstance(built, str) else f"{built[0]}\n{built[1]}"


def only_the_ask_differs(hist, level, total_rounds, agent_now,
                         rules_shown=False, forms=None):
    rnd = 1 + len(hist)
    stripped = set()
    for form, verb in conditions(forms):
        text = _as_text(build_prediction(hist, level, total_rounds, form,
                                         verb, agent_now, rules_shown))
        line = ask(form, verb, rnd)
        if line not in text:
            return False, f"{form}/{verb}: ask line not found in the prompt"
        stripped.add(text.replace(line, "<ASK>"))
    if len(stripped) != 1:
        return False, f"{len(stripped)} distinct documents, expected 1"
    return True, ""


def ask_is_one_line(hist, level, total_rounds, agent_now, forms=None):
    rnd = 1 + len(hist)
    for form, verb in conditions(forms):
        if "\n" in ask(form, verb, rnd):
            return False, f"{form}/{verb} spans more than one line"
    return True, ""


def levels_nest():
    if TASK_LINE["L3"] != f"{TASK_LINE['L1']} {TASK_LINE['L2']}":
        return False, "L3 is not L1 + L2"
    return True, ""


# the hidden prompt must not leak the relation anywhere; checked in code
# because one stray "beats" would quietly turn this into the experiment
# it's supposed to be contrasted against
def rule_is_hidden(hist, level, total_rounds, agent_now):
    text = _as_text(build_prediction(hist, level, total_rounds, "question",
                                     "predict", agent_now,
                                     rules_shown=False)).lower()
    # The rule probe is part of this document when RULE_PROBE is on, so
    # it's covered by the same check: asking what the opponent is doing
    # must never name which move beats which.
    return "beats" not in text and "beat " not in text


# hidden and given must differ by the beats line and nothing else. Chat
# control tokens are stripped before comparing, since <|im_end|> attaches
# to whatever the last line of a turn happens to be, so adding the beats
# line moves it to a different line and a naive diff would report two
# changes for what's really one
def hidden_given_differ_by_one_line(hist, level, total_rounds, agent_now):
    def lines(rs):
        text = _as_text(build_prediction(hist, level, total_rounds, "question",
                                         "predict", agent_now, rules_shown=rs))
        for tok in (IM_END, IM_START):
            text = text.replace(tok, "")
        return [l for l in text.split("\n") if l.strip()]

    a, b = lines(False), lines(True)
    diff = [l for l in b if l not in a]
    return diff == [game.BEATS_LINE], diff


# nothing beside the cue that reads as a hint about the answer
def nothing_to_copy(hist, level, total_rounds, agent_now):
    built = build_prediction(hist, level, total_rounds, "question", "predict",
                             agent_now)
    if config.GENERATES:
        _s, user = built
        if not user.rstrip().endswith("<one of the moves>"):
            return False, f"does not end with the spec: {user[-40:]!r}"
        if config.RULE_PROBE and RULE_LABEL not in user:
            return False, "RULE_PROBE is on but the rule line is missing"
        return True, ""
    lines = built.split("\n")
    if lines[-1] != game.OPPONENT_LABEL:
        return False, f"does not end at the cue: {lines[-1]!r}"
    if "<think>" in built.lower():
        return False, "a <think> block was appended; thinking must stay off"
    above = (lines[-3] if len(lines) >= 3 else "").replace(IM_END, "")
    if "<" in above or "..." in above:
        return False, f"template-like line above the cue: {above!r}"
    if above.strip().split()[:1] == ["Round"]:
        return False, f"bare round row above the cue: {above!r}"
    if sum(1 for m in game.MOVES if m in above) >= 2:
        return False, f"option list beside the cue: {above!r}"
    return True, ""
