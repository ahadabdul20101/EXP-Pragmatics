# game.py  (arm: relationderivation)
# A three-move game where the rule is never stated.
#
# The prompt doesn't say what beats what. The model has to work that out
# from the outcome lines, and only then can it predict the opponent. Two
# things have to be learned, in order:
#
#   1. the beats relation      F beats J, M beats F, J beats M
#   2. the opponent's policy   which differs per opponent, and for two of
#                              the five doesn't involve the relation at all
#
# Step 1 is the part every other arm gets for free in its rules block.
#
# Which opponents actually test it:
#
#   counter   plays what beats your CURRENT move      needs the relation
#   tft       plays what beats your PREVIOUS move      needs the relation
#   mirror    copies your previous move                does NOT
#   cycle     fixed sequence, ignores you              does NOT
#   random    nothing                                  does NOT
#
# The last three are controls, not easier versions of the test -- they say
# what's solvable without the relation, which is what makes the first two
# interpretable: if the model scores the same on mirror as on tft, it's
# tracking sequences rather than applying a rule it actually derived.

import hashlib
import random

import config

MOVES = ["J", "F", "M"]
MOVE_LIST = ", ".join(MOVES)

# BEATS[x] is the move that beats x. Never written into any prompt.
BEATS = {"J": "F", "F": "M", "M": "J"}
LOSES_TO = {v: k for k, v in BEATS.items()}

AGENT_LABEL = "You played:"
OPPONENT_LABEL = "Opponent played:"


def rng_for(*parts):
    key = "|".join(str(p) for p in parts)
    return random.Random(int(hashlib.sha256(key.encode()).hexdigest()[:16], 16))


def outcome(agent, opp):
    if agent == opp:
        return "tie"
    return "opponent" if BEATS[agent] == opp else "you"


# the only channel through which the beats relation is ever taught
def outcome_line(agent, opp):
    return {"opponent": "Opponent won", "you": "You won",
            "tie": "Tie"}[outcome(agent, opp)]


# ── the policies ─────────────────────────────────────────────────────────────

# what the opponent's policy says to play this round. `agent_now` is only
# used by `counter`, which is the one opponent that responds within the
# round rather than to history
def _rule_move(kind, agent_now, prev_agent, prev_opp, rnd, start):
    if kind == "counter":
        return BEATS[agent_now]
    if kind == "tft":
        return start if prev_agent is None else BEATS[prev_agent]
    if kind == "mirror":
        return start if prev_agent is None else prev_agent
    if kind == "cycle":
        return MOVES[(MOVES.index(start) + rnd) % 3]
    raise ValueError(f"no rule for {kind!r}")


OPPONENTS = ("counter", "tft", "mirror", "cycle", "random")


# scripted transcript, fully determined by (kind, seed).
#
# Noise applies to `counter` only, and that's a deliberate asymmetry. The
# relation is taught by the outcome lines, so all three outcome types have
# to show up. A same-round counter wins every round by construction, so
# without deviations it would only ever demonstrate "the move that beats
# yours wins" and the relation would never get pinned down from the other
# side. The other four opponents don't respond to the current move, and the
# agent plays at random, so wins, losses and ties already occur naturally
# there -- adding noise would just make their patterns harder to see for no
# gain.
#
# `rule_move` is stored per round: what the policy would have played. On a
# counter deviation it differs from what was actually played, which lets
# the analysis separate "knows the rule" from "got the round right".
def make_transcript(kind, seed, n_rounds, noise):
    if kind not in OPPONENTS:
        raise ValueError(f"unknown opponent {kind!r}")
    agent_rng = rng_for("agent", kind, seed)
    opp_rng = rng_for("opp", kind, seed)
    noise_rng = rng_for("noise", kind, seed)
    start = rng_for("start", kind, seed).choice(MOVES)

    hist = []
    prev_agent = prev_opp = None
    for rnd in range(n_rounds):
        # The agent's move is drawn first because `counter` responds to it.
        agent = agent_rng.choice(MOVES)

        if kind == "random":
            rule = None
            opp, dev = opp_rng.choice(MOVES), 0
        else:
            rule = _rule_move(kind, agent, prev_agent, prev_opp, rnd, start)
            if kind != "counter":
                opp, dev = rule, 0
            else:
                roll = noise_rng.random()
                if roll >= noise:
                    opp, dev = rule, 0
                elif roll < noise / 2:
                    opp, dev = agent, 1            # deviation: a tie
                else:
                    opp, dev = LOSES_TO[agent], 1  # deviation: opponent loses

        hist.append({"agent": agent, "opponent": opp, "rule_move": rule,
                     "deviation": dev, "outcome": outcome(agent, opp)})
        prev_agent, prev_opp = agent, opp
    return hist


# ── the derivability guarantee ───────────────────────────────────────────────

# which of the three beats facts the history has actually demonstrated. A
# fact is demonstrated by any decisive round: whoever won played the move
# that beats the loser's. Ties teach nothing about the relation.
#
# This is a design guarantee, not a statistic. If a history doesn't
# demonstrate all three, the question isn't answerable and the row must not
# be averaged in. --self-test reports when each seed reaches three.
def beats_facts_shown(hist):
    facts = set()
    for r in hist:
        if r["outcome"] == "opponent":
            facts.add((r["agent"], r["opponent"]))
        elif r["outcome"] == "you":
            facts.add((r["opponent"], r["agent"]))
    return facts


# ── rendering ────────────────────────────────────────────────────────────────

# one block per round; the outcome line is what carries the rule. The
# labels carry their colon, so the cue "Opponent played:" is a string the
# document has already shown once per round. A cue that appears nowhere
# above it has no precedent to complete, and coverage collapses.
def format_history(hist, first_round=1):
    if not hist:
        return "No rounds have been played yet."
    return "\n\n".join(
        f"Round {first_round + i}\n"
        f"{AGENT_LABEL} {r['agent']}\n"
        f"{OPPONENT_LABEL} {r['opponent']}\n"
        f"{outcome_line(r['agent'], r['opponent'])}"
        for i, r in enumerate(hist))


# the move labels still have to be named, or the model doesn't know the
# answer space and coverage collapses for reasons unrelated to the
# experiment. Naming the options is not naming the relation, and only the
# relation is hidden.
def rules_block(total_rounds, rules_shown=False):
    head = (f"You are playing {total_rounds} rounds of a game against another "
            f"player.\nEach round you both pick one of: {MOVE_LIST}.\n"
            f"Each round shows what each player picked and who won.")
    return f"{head}\n{BEATS_LINE}" if rules_shown else head


# The one line that `rules_shown` adds. Kept as a constant so --self-test
# can assert that hidden and given differ by exactly this and nothing else.
BEATS_LINE = "F beats J, M beats F, J beats M. Same pick is a tie."


# ── baselines ────────────────────────────────────────────────────────────────

# trivial rules, stored per row so accuracy is never read alone. None of
# these needs the beats relation, so model behaviour matching any of them
# means the relation wasn't what produced the answer.
def baselines(hist, agent_now):
    return {
        "opp_last": hist[-1]["opponent"] if hist else None,
        "own_last": hist[-1]["agent"] if hist else None,
        "copy_you": agent_now,
        "modal": (max(MOVES, key=lambda m: (sum(1 for r in hist
                                                if r["opponent"] == m), m))
                  if hist else None),
    }
