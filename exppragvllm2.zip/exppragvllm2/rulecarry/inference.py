# inference.py  (arm: rulecarry)
# The generating path: ask, then parse the answer line. Direct descendant of
# notemp2's inference.py, with the two failures vllm1 exposed fixed.
#
# What's kept from notemp2, because it was right:
#   - LAST match wins, never first. The model names moves while reasoning
#     ("Round 1: F ..."), so first-match returns its description of the
#     history instead of its answer.
#   - Longest-first move alternation, so a multi-character label is never
#     truncated to its first letter.
#   - A labelled line beats an unlabelled mention.
#   - A missing answer line is a parse failure that fires the retry loop, not
#     something to paper over. The permissive fallback runs only after every
#     attempt has failed, and the row is flagged so it can be excluded.
#   - Synonym labels. notemp2 recognised only two exact strings, so "Answer:
#     J" fell through to the fallback -- 938 of 3,000 rows (31%), scoring at
#     chance because the fallback inverts on negation.
#   - The negation guard on the fallback.
#   - notemp2's sampling exactly: temperature 0.7, top_p 0.8, top_k 20,
#     presence_penalty 1.5, thinking off. PRESENCE_PENALTY is the documented
#     lever against endless repetition, and a transformers port of this
#     harness silently dropped it because transformers has no such parameter.
#
# ─────────────────────────────────────────────────────────────────────────────
# What vllm1 got wrong, and what changed here.
#
# 1. Truncation was accepted as a clean parse.
#
#    The old loop read:
#
#        raw, cut = call(...)
#        mv, tier, line = extract(raw)
#        if mv:                          # <- no check on `cut`
#            return {... "truncated": int(cut), "no_answer_line": 0 ...}
#
#    so a response that ran out of tokens was accepted on attempt 1 whenever
#    the parser found anything at all, and it passed the `clean` view. The
#    retry machinery never ran: `attempts` averaged 1.12-1.18 against 19-48%
#    truncation.
#
#    The damage was not missing rows, it was wrong ones:
#
#        opponent   untruncated   truncated     gap
#        cycle          91.9         29.3     -62.6
#        tft            60.1         29.0     -31.1
#        mirror         68.5         44.1     -24.4
#        random         34.7         32.9      -1.8
#
#    Random is the control that proves the mechanism: it has the most
#    truncation (48%) and the smallest gap, because there is no signal to
#    lose. Where the task is solvable the truncated rows sit at chance.
#
# 2. Tier 2 was mining the model's narration of the history.
#
#    `_PAT_INLINE` is unanchored and the label family includes ordinary
#    prose -- "Opponent plays", "Opponent's move" -- which is exactly how the
#    model restates the history while reasoning. On a response that never
#    reached a conclusion, last-match-wins then returns the final restatement.
#
#    Measured: the answer line sat at 0.43-0.51 of the way through truncated
#    responses (80-85% of them before the 80% mark) against 0.90-0.94 for
#    untruncated ones.
#
#    Fix: tier 2 is restricted to the tail of the response, and skipped
#    entirely when the response was cut off. Tier 1 is anchored at line start
#    and is largely immune, because narration sits inside numbered list items.
#
# 3. The fix for (1) cannot be "retry".
#
#    Retrying the same prompt runs out of tokens again -- random/L3 truncated
#    87% of the time, and the cause is the L3 search instruction, which has no
#    stopping condition when there is no pattern to find. So on truncation the
#    partial reasoning is fed back as an assistant turn and the model is asked
#    to land it in ten words. That keeps the work it already did, and it
#    leaves the first-stage prompt untouched, which matters because all 38
#    conditions must stay byte-identical apart from the ask.
#
# 4. Everything is stored, so a parser bug never costs a rerun again.
#
#    `raw_response` holds the complete first-stage text, always, never sliced.
#    `raw_exit` holds the forced-exit reply. `parse_tier` records which pass
#    produced the answer -- it was returned by predict() in vllm1 and silently
#    dropped, because it was missing from database.COLUMNS. Anything the
#    parser gets wrong can be re-derived offline from these columns.

import json
import re
import sys
import urllib.error
import urllib.request

import config
import game

_ENDPOINT = f"http://{config.VLLM_HOST}:{config.VLLM_PORT}/v1/chat/completions"

truncated_calls = 0
forced_exit_calls = 0
forced_exit_rescued = 0
_STUB = False

# How much of the end of a response tier 2 is allowed to look at. A real
# conclusion lands in the last line or two; history narration is spread
# through the whole text. 400 characters is roughly the last two sentences.
TAIL_CHARS = 400


# switches call()/forced_exit() over to the deterministic stub responses
def use_stub():
    """Without this a --dry-run fails every call against a server that is not
    there, fills the move, and reports a clean-looking run built on failures."""
    global _STUB
    _STUB = True


# a plausible first-stage reply derived from the prompt, for dry runs
def _stub_response(system, user, seed):
    """A plausible reply derived from the prompt, so a dry run is
    deterministic and the parser is genuinely exercised -- including the
    refusal paths, which an always-well-formed stub would never reach."""
    import hashlib
    d = hashlib.sha256(f"{user}|{seed}".encode()).digest()
    mv = game.MOVES[d[0] % len(game.MOVES)]
    shape = d[1] % 8
    if shape == 0:                      # no answer line at all
        return "The history is too short to be sure of the pattern.", False
    if shape == 1:                      # the notemp2 negation case
        return f"They would likely play {mv} and not {game.BEATS[mv]}.", False
    if shape == 2:                      # truncated mid-narration -- the vllm1
        return (                        # failure, verbatim in shape
            f"Round 1: {game.OPPONENT_LABEL}: {game.MOVES[d[2] % 3]}. "
            f"Round 2: {game.OPPONENT_LABEL}: {game.MOVES[d[3] % 3]}. "
            "Looking further at the sequence " * 8), True
    if shape == 3:                      # a synonym label
        return f"The sequence repeats every three rounds.\nAnswer: {mv}", False
    guesses = ["it copies my previous move",
               "it plays whatever beats my last move",
               "it cycles through the moves in a fixed order",
               "it plays at random"]
    return (f"The opponent has been cycling. Round {d[2] % 40 + 1} was "
            f"{game.MOVES[d[3] % 3]}, which fits.\n"
            f"Rule: {guesses[d[4] % 4]}\n"
            f"{game.OPPONENT_LABEL}: {mv}"), False


# the forced-exit stub reply, short and well formed by design
def _stub_exit(seed):
    """The forced-exit stub. Short and well formed, which is the point of it."""
    import hashlib
    d = hashlib.sha256(f"exit|{seed}".encode()).digest()
    if d[0] % 10 == 0:                  # it sometimes still refuses
        return "I cannot be certain from this history.", False
    return f"{game.OPPONENT_LABEL}: {game.MOVES[d[1] % 3]}", False


# Longest first, so "Scissors" is never truncated to "S" under the words scheme.
_ALT = "|".join(re.escape(m) for m in sorted(game.MOVES, key=len, reverse=True))

# The label asked for, plus the ways models actually phrase it. Not
# recognising these was what sent a third of notemp2's rows to the fallback.
#
# NOTE the two marked entries. They are ordinary narration as well as answer
# labels, which is why tier 2 is tail-restricted: at the end of a finished
# reply "the opponent's move will be F" is a conclusion, in the middle of one
# it is a description of round 7.
_LABEL_FORMS = [
    game.OPPONENT_LABEL,          # "Opponent move" -- what the spec asks for
    game.AGENT_LABEL,
    "Opponent will play",
    "Opponent plays",             # <- also narration
    "Opponent's move",            # <- also narration
    "Predicted move",
    "My prediction",
    "Prediction",
    "Final answer",
    "Answer",
]
_LABELS = "|".join(re.escape(l) for l in
                   sorted(_LABEL_FORMS, key=len, reverse=True))

# Cues that mean a move is being ruled OUT. The fallback refuses any sentence
# containing one, because that is exactly where the old behaviour inverted.
_NEGATION = re.compile(
    r"\b(not|never|unlikely|rather than|instead of|isn't|wasn't|won't|"
    r"doubt|avoid|except|other than|no longer|rule out|ruled out)\b", re.I)

_PAT_LINE = re.compile(rf'^\s*(?:{_LABELS})\s*[:\-]?\s*({_ALT})\b', re.M | re.I)
_PAT_INLINE = re.compile(rf'\b(?:{_LABELS})\s*[:\-]?\s+({_ALT})\b', re.I)
_PAT_BARE = re.compile(rf'\b({_ALT})\b')


# canonical move spelling for a matched string, case-insensitively
def _canon(found):
    for m in game.MOVES:
        if m.lower() == found.lower():
            return m
    return None


# parses the model's move out of its reply, trying each tier in order
def extract(text, require_label=None, truncated=False):
    """Return (move, tier, answer_line).

    tier 1  a labelled line anchored at line start -- what the spec asks for
    tier 2  a label inline, IN THE TAIL ONLY, and never on a truncated reply
    tier 3  the permissive fallback: last bare move token, and ONLY when
            require_label is off. Refused if the sentence holding it contains
            a negation cue.

    Returns (None, None, None) when nothing can be read honestly, which is the
    correct answer often enough that it has its own retry path.
    """
    if not text:
        return None, None, None
    if require_label is None:
        require_label = config.REQUIRE_ANSWER_LINE

    # Tier 1 reads the whole text: it is anchored at line start, and the
    # model's narration of the history sits inside numbered list items
    # ("1. **Round 3**: ...") which do not begin with a bare label.
    hits = list(_PAT_LINE.finditer(text))
    if hits:
        mv = _canon(hits[-1].group(1))
        if mv:
            return mv, 1, text[hits[-1].start():hits[-1].end()].strip()

    # Tier 2 is where vllm1 went wrong. Two constraints now:
    #   - never on a truncated reply, which by definition has no conclusion
    #   - only in the tail, where a conclusion would be
    if not truncated:
        tail = text[-TAIL_CHARS:]
        hits = list(_PAT_INLINE.finditer(tail))
        if hits:
            mv = _canon(hits[-1].group(1))
            if mv:
                return mv, 2, tail[hits[-1].start():hits[-1].end()].strip()

    if require_label:
        return None, None, None

    # Last resort. Sentence-scoped and negation-guarded, so it cannot repeat
    # the "F and not J -> J" failure that made the old fallback score at
    # chance. Refused outright on a truncated reply.
    if truncated:
        return None, None, None
    for chunk in reversed(re.split(r"(?<=[.!?])\s+|\n+", text.strip())):
        if not chunk.strip() or _NEGATION.search(chunk):
            continue
        found = _PAT_BARE.findall(chunk)
        if found:
            mv = _canon(found[-1])
            if mv:
                return mv, 3, chunk.strip()[:120]
    return None, None, None


_PAT_RULE = re.compile(r"^\s*Rule\s*:\s*(.+)$", re.M | re.I)


# pulls the model's stated belief about the opponent's strategy out of the text
def extract_rule(text):
    """The model's stated belief about the opponent's strategy, verbatim.

    Returned as written, with no scoring and no normalisation. Whether a
    sentence counts as the right rule is decided offline in belief.py, so
    changing that judgement never means rerunning the job.

    LAST match wins, for the same reason the move parser does: the model
    often restates earlier guesses while reasoning, and the final one is the
    belief it is committing to.
    """
    if not text:
        return None
    hits = _PAT_RULE.findall(text)
    return hits[-1].strip()[:400] if hits else None


# where the answer line sits in the response, as a fraction of its length
def answer_position(text, answer_line):
    """Where the answer line sits, as a fraction of the response length.

    Stored per row so the tier-2 failure mode is auditable from the database
    instead of needing the raw text re-read. Near 1.0 is a conclusion; 0.4 is
    a restatement of the history with the real answer never written.
    """
    if not text or not answer_line:
        return None
    idx = text.rfind(answer_line)
    return round(idx / len(text), 4) if idx >= 0 and len(text) else None


# sends one chat-completions request and returns the parsed JSON, or None
def _post(payload):
    req = urllib.request.Request(
        _ENDPOINT, data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req,
                                    timeout=config.REQUEST_TIMEOUT_S) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        print(f"    [inference] HTTP {e.code}: "
              f"{e.read().decode(errors='replace')[:300]}",
              file=sys.stderr, flush=True)
    except Exception as e:
        print(f"    [inference] request failed: {e}",
              file=sys.stderr, flush=True)
    return None


# the sampling parameters shared by both the first-stage and exit requests
def _sampling():
    return {
        "model": config.VLLM_SERVED_NAME,
        "temperature": config.TEMPERATURE,
        "top_p": config.TOP_P,
        "top_k": config.TOP_K,
        "min_p": config.MIN_P,
        "presence_penalty": config.PRESENCE_PENALTY,
        "chat_template_kwargs": {"enable_thinking": config.ENABLE_THINKING},
    }


# makes the first-stage generation call
def call(system, user, seed):
    """One first-stage request. Returns (text, truncated)."""
    global truncated_calls
    if _STUB:
        return _stub_response(system, user, seed)

    payload = dict(_sampling(),
                   messages=[{"role": "system", "content": system},
                             {"role": "user", "content": user}],
                   max_tokens=config.MAX_NEW_TOKENS,
                   seed=seed)
    data = _post(payload)
    if data is None:
        return None, False
    choice = data["choices"][0]
    cut = choice.get("finish_reason") == "length"
    if cut:
        truncated_calls += 1
    return (choice["message"]["content"] or "").strip(), cut


# asks the model to land its answer in ten words after a truncated reply
def forced_exit(system, user, partial, seed):
    """Second stage, only after the first hit the cap. Returns (text, cut).

    The partial reasoning goes back as an assistant turn, so the model
    finishes its own thought rather than starting over. EXIT_MAX_TOKENS is
    small by design: the ask is for ten words, and a large budget here would
    just reproduce the problem.
    """
    global forced_exit_calls
    forced_exit_calls += 1
    if _STUB:
        return _stub_exit(seed)

    payload = dict(_sampling(),
                   messages=[{"role": "system", "content": system},
                             {"role": "user", "content": user},
                             {"role": "assistant", "content": partial},
                             {"role": "user",
                              "content": prompts_forced_exit_user()}],
                   max_tokens=config.EXIT_MAX_TOKENS,
                   seed=seed + 1)
    data = _post(payload)
    if data is None:
        return None, False
    choice = data["choices"][0]
    return ((choice["message"]["content"] or "").strip(),
            choice.get("finish_reason") == "length")


# the forced-exit instruction text, imported lazily to avoid a hard dependency
def prompts_forced_exit_user():
    """Imported lazily so inference.py stays importable on its own, which is
    what lets the offline re-parser replay extract() without the arm's
    prompt module."""
    import prompts
    return prompts.forced_exit_user()


# assembles the stored-row dict for one predict() outcome
def _row(mv, tier, line, *, attempts, raw, exit_raw, cut, forced, failed):
    # The rule is read from the FIRST stage even on a forced exit: the belief
    # sentence is written before the move line, so a reply cut off after the
    # rule still carries it. That is the case worth keeping -- it is exactly
    # the round where the model had a belief and ran out of room to act on it.
    rule = extract_rule(raw) or extract_rule(exit_raw)
    return {
        "rule_stated": rule,
        "prediction": mv,
        "parse_tier": tier,
        "answer_line": line,
        "attempts": attempts,
        "raw_response": raw,            # ALWAYS the complete first stage
        "raw_exit": exit_raw,
        "reasoning": raw,               # never sliced; kept for readability
        "truncated": int(bool(cut)),
        "forced_exit": int(bool(forced)),
        "no_answer_line": int(bool(failed)),
        # Only meaningful for a first-stage parse: it exists to catch
        # tier 2 mining the model's narration of the history. A
        # forced-exit reply IS the answer line, so the number would
        # always be 0.0 and would say nothing.
        "answer_pos": None if forced else answer_position(raw, line),
        "n_gen_chars": len(raw or ""),
    }


# generates and retries until the answer parses honestly, or falls back
def predict(system, user, seed):
    """Generate until the answer parses honestly. Returns a dict for the row.

    Order of resort, and why each step is there:

      1. generate                     the normal path
      2. if it parsed AND was not cut return it
      3. if it was cut, forced exit   the reasoning is kept, not discarded
      4. otherwise retry              a different sample of the same prompt
      5. after RETRY_MAX, fall back   permissively, and FLAG the row

    A row that reaches step 5 carries no_answer_line = 1 and is dropped by the
    `clean` view. That is the honest outcome, and vllm1's mistake was making
    step 2 fire on truncated responses so steps 3-5 never ran.
    """
    global forced_exit_rescued
    last_raw, last_cut = None, False

    for attempt in range(config.RETRY_MAX):
        raw, cut = call(system, user, seed * 1_000_003 + attempt)
        if not raw:
            continue
        last_raw, last_cut = raw, cut

        if not cut:
            mv, tier, line = extract(raw, require_label=True, truncated=False)
            if mv:
                return _row(mv, tier, line, attempts=attempt + 1, raw=raw,
                            exit_raw=None, cut=False, forced=False,
                            failed=False)
            continue

        # Cut off. Hand the partial reasoning back and ask for ten words.
        exit_raw, _exit_cut = forced_exit(system, user, raw,
                                          seed * 1_000_003 + attempt)
        if exit_raw:
            mv, tier, line = extract(exit_raw, require_label=True,
                                     truncated=False)
            if mv:
                forced_exit_rescued += 1
                return _row(mv, tier, line, attempts=attempt + 1, raw=raw,
                            exit_raw=exit_raw, cut=True, forced=True,
                            failed=False)

    # Every attempt failed. Fall back once, permissively, so the row still
    # carries a move -- but flagged, because this answer is a guess. Refused
    # outright when the last response was truncated, since mining an
    # unfinished reply is the exact failure this rewrite exists to remove.
    if last_raw:
        mv, tier, line = extract(last_raw, require_label=False,
                                 truncated=last_cut)
        return _row(mv, tier, line, attempts=config.RETRY_MAX, raw=last_raw,
                    exit_raw=None, cut=last_cut, forced=False, failed=True)

    return _row(None, None, None, attempts=config.RETRY_MAX, raw=None,
                exit_raw=None, cut=False, forced=False, failed=True)


# a small summary dict, printed at the end of a run
def stats():
    """Printed at the end of a run, so truncation is visible without a query."""
    return {"truncated_calls": truncated_calls,
            "forced_exit_calls": forced_exit_calls,
            "forced_exit_rescued": forced_exit_rescued}
