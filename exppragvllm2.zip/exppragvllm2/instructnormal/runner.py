# runner.py  (arm: instructnormal)
# One cell = (verb, level, opponent, seed). Every cell reads the SAME scripted
# transcript for its (opponent, seed), so verbs compare round by round.
#
# Prediction only. notemp2 asked a second question each round -- what do you
# play -- which is the belief-to-action gap. The verb manipulation is about
# prediction, and here a second probe would mean a second full generation per
# round, so it is not asked.

import config
import database
import game
import inference
import prompts


_COLNAMES = {n for n, _ in database.COLUMNS}


# a fresh result row, with every unfilled column left NULL rather than 0
def _row(**kw):
    """Every column starts NULL, so a column this arm does not fill stays
    empty rather than silently defaulting to 0."""
    base = {n: None for n, _ in database.COLUMNS}
    base.update({"arm": config.ARM, "model_kind": config.MODEL_KIND,
                 "parse_failed": 0})
    base.update(kw)
    return base


# plays out one (form, verb, level, opponent, seed) cell and probes it on
# the scheduled rounds
def run_cell(form, verb, level, opponent, seed):
    total = config.TOTAL_ROUNDS
    script = game.make_script(opponent, seed, total)
    scheduled = set(config.probe_rounds(total))
    hist, records = [], []

    for i in range(total):
        rnd = i + 1
        opp_move = script[i]["opponent"]

        # Round 1 has no history to predict from, and the schedule thins
        # out after the belief curve has flattened: each probe here is a full
        # generation, not a single token.
        if rnd not in scheduled:
            hist.append(script[i])
            continue

        sysmsg, user = prompts.build_prediction(hist, level, total, form, verb,
                                                feedback=config.FEEDBACK)
        got = inference.predict(sysmsg, user, seed * 100_000 + rnd)
        pred = got["prediction"]

        b = game.baselines(hist)
        rule = b.get(f"{opponent}_rule")
        records.append(_row(
            form=form, verb=verb,
            level_name=prompts.level_name(verb), task_level=level,
            question=prompts.ask(form, verb, rnd),
            opponent=opponent, seed=seed, round_num=rnd,
            truth=opp_move, prediction=pred,
            # NULL, not 0, when nothing could be read. A refusal is not a
            # wrong answer, and counting it as one understates accuracy by
            # exactly the refusal rate.
            prediction_correct=(int(pred == opp_move) if pred else None),
            switched=int(bool(hist) and opp_move != hist[-1]["opponent"]),
            opponent_move=opp_move, model_move=script[i]["model"],
            b_opp_last=int(b["opp_last"] == opp_move),
            b_own_last=int(b["own_last"] == opp_move),
            b_modal=int(b["modal"] == opp_move),
            b_true_rule=(int(rule == opp_move) if rule is not None else None),
            parse_failed=int(pred is None),
            # Everything inference.predict() produced, passed straight
            # through. vllm1 hand-listed these keys and silently dropped
            # parse_tier, because the column did not exist; the diagnosis of
            # the truncation bug then needed the parser replayed offline.
            # Filtering on COLUMNS means a new key is stored the moment the
            # schema gains it, and a key with no column is a loud KeyError
            # rather than a quiet loss.
            **{k: v for k, v in got.items()
               if k in _COLNAMES and k != "prediction"}))

        hist.append(script[i])

    return records
