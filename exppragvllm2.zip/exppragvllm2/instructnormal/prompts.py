# prompts.py  (arm: instructnormal)


import re

import config
import game

#  the four forms 
#
# 
#
#   question      interrogative, verb inside a fixed frame   (vllm1's form)
#   statement     imperative, the verb carries the whole ask
#   statement_n   the same imperative, naming the round explicitly
#   taskverb      the vllm1 `task` condition, with the verb now varied
#



FORMS = ("question", "statement", "statement_n", "taskverb")

FRAMES = {
    "question":    "What do you {verb} the other player will play in this round?",
    "statement":   "{Verb} the other player's move in this round.",
    "statement_n": "{Verb} the other player's move in round {n}.",
    "taskverb":    "Your task is to {verb} the other player's move in this round.",
}

#  the verb bank 
#
# Three verbs per epistemic level is what turns the level into the effect

#
# `say` is the matched neutral control, near-zero epistemic content in the
# identical frame. 

VERBS = {
    "predict":    "high",     # articulate, model-based commitment
    "forecast":   "high",
    "infer":      "high",
    "expect":     "mid",      # expectation without a strong warrant
    "anticipate": "mid",
    "estimate":   "mid",
    "guess":      "low",      # explicitly low confidence
    "suppose":    "low",
    "imagine":    "low",
    "say":        "neutral",  # matched control, same frame
}

EPISTEMIC = tuple(v for v, lvl in VERBS.items() if lvl != "neutral")

# The frameless anchor. No verb
NO_VERB = "Which move will the other player play in this round?"


# every (form, verb) pair in the design, in a stable order
def conditions():
 
    out = [("question", v) for v in VERBS]
    out.append(("question", "none"))
    for form in ("statement", "statement_n", "taskverb"):
        out += [(form, v) for v in EPISTEMIC]
    return out


# the one line that varies; everything else in the prompt is fixed
def ask(form, verb, rnd):
    if form not in FRAMES:
        raise ValueError(f"unknown form {form!r}")
    if verb == "none":
        if form != "question":
            raise ValueError("the frameless anchor exists only as a question")
        return NO_VERB
    if verb not in VERBS:
        raise ValueError(f"unknown verb {verb!r}")
    return FRAMES[form].format(verb=verb, Verb=verb.capitalize(), n=rnd)


# the verb's epistemic level, or "none" for the frameless anchor
def level_name(verb):
    return "none" if verb == "none" else VERBS[verb]


# the longest ask line across every condition, for sizing checks
def longest_ask(rnd=100):
    return max((ask(f, v, rnd) for f, v in conditions()), key=len)


# task framing 

SEARCH = ("Your task is to find the pattern in the history and use it to "
          "predict.")
POINTER = ("The opponent's move depends on what you played in the previous "
           "round.")

TASK_LINE = {
    "L0": "",
    "L1": SEARCH,
    "L2": POINTER,
    "L3": f"{SEARCH} {POINTER}",     # byte-identical to vllm1's L3
}

LEVEL_DESCRIPTIONS = {
    "L0": "no framing",
    "L1": "search only",
    "L2": "pointer only",
    "L3": "search + pointer",
}


# the task line for this level, with its trailing newline if non-empty
def _task(level):
    if level not in TASK_LINE:
        raise ValueError(f"unknown level {level!r}")
    return f"{TASK_LINE[level]}\n" if TASK_LINE[level] else ""


# ── assembly 

# the format spec, generating mode only. Named label, no example move, no
# option list -- notemp2's wording, kept so parse rates stay comparable

def spec():
    return (f"Your answer MUST end with a line formatted exactly like:\n"
            f"{game.OPPONENT_LABEL}: <one of the moves>")


def body(hist, level, total_rounds, form, verb, feedback=False):
    rnd = len(hist) + 1
    return (f"{game.format_history(hist, agent_first=False, feedback=feedback)}"
            f"\n\n{_task(level)}"
            f"You are currently playing round {rnd}.\n"
            f"{ask(form, verb, rnd)}")


# returns (system, user) for the chat endpoint
def build_prediction(hist, level, total_rounds, form, verb, feedback=False):
    return (game.rules_block(total_rounds),
            f"{body(hist, level, total_rounds, form, verb, feedback)}"
            f"\n{spec()}")


# the second-stage ask, sent only when the first call hit the token cap.

def forced_exit_user():
    return ("Stop reasoning now. In ten words or fewer, give only your final "
            "answer, formatted exactly like:\n"
            f"{game.OPPONENT_LABEL}: <one of the moves>")


#  guards 

# true if all 38 conditions give the same document apart from one line; the
# generating arm builds a (system, user) pair, so the two turns are joined
# before comparing
def only_the_ask_differs(hist, level, total_rounds):
    rnd = len(hist) + 1
    stripped = set()
    for form, verb in conditions():
        system, user = build_prediction(hist, level, total_rounds, form, verb)
        text = f"{system}\n{user}"
        line = ask(form, verb, rnd)
        if line not in text:
            return False, f"{form}/{verb}: ask line not found in the prompt"
        stripped.add(text.replace(line, "<ASK>"))
    if len(stripped) != 1:
        return False, f"{len(stripped)} distinct documents, expected 1"
    return True, ""


# each form must occupy exactly one line, or the cue's position relative to
# the round line shifts -- the geometry the 0.61-vs-0.99 finding was about
def ask_is_one_line(hist, level, total_rounds):
    rnd = len(hist) + 1
    for form, verb in conditions():
        if "\n" in ask(form, verb, rnd):
            return False, f"{form}/{verb} spans more than one line"
    return True, ""


# L3 must be exactly L1 plus L2, or the split doesn't decompose it
def levels_nest(_hist=None):
    if TASK_LINE["L3"] != f"{TASK_LINE['L1']} {TASK_LINE['L2']}":
        return False, "L3 is not L1 + L2"
    return True, ""


# nothing beside the ask that could read as a hint about the answer. The
# generating arm has no cue, since free generation has nowhere to prefill,
# so what's checked instead is that the user turn ends with the format spec
# and that the spec never names a move
def nothing_to_copy(hist, level, total_rounds):
    _system, user = build_prediction(hist, level, total_rounds,
                                     "question", "predict")
    if not user.rstrip().endswith("<one of the moves>"):
        return False, f"user turn does not end with the spec: {user[-40:]!r}"
    if any(re.search(rf"\b{m}\b", spec()) for m in game.MOVES):
        return False, "the format spec names a move"
    return True, ""
