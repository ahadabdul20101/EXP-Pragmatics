# game.py
# Labels, opponents, scripted transcripts, history rendering, baselines.
#
# Everything here is scripted. The agent's moves come from a seeded RNG and
# the opponent answers by its rule, so the whole transcript exists before
# the model is ever called. That's what makes the verb comparison exact:
# every verb reads the same history at the same round, byte for byte, and
# the rows can be paired up afterwards.
#
# Live play would break that. The model's own predictions would change what
# it plays, the histories would diverge between verbs, and round 50 for
# `predict` would no longer line up with round 50 for `guess`.

import hashlib
import random

import config

_SCHEMES = {"neutral": ["J", "F", "M"],
            "native":  ["R", "P", "S"],
            "words":   ["Rock", "Paper", "Scissors"]}

if config.LABEL_SCHEME not in _SCHEMES:
    raise ValueError(f"unknown LABEL_SCHEME {config.LABEL_SCHEME!r}")

MOVES = _SCHEMES[config.LABEL_SCHEME]
# Distinct first letters, which scoring.py's prefix matching relies on.
assert len({m[0].lower() for m in MOVES}) == 3, "moves must differ in letter 1"

BEATS = {MOVES[i]: MOVES[(i + 1) % 3] for i in range(3)}
MOVE_LIST = ", ".join(MOVES)

AGENT_LABEL = "Your move"
OPPONENT_LABEL = "Opponent move"
PRED_LABEL = "Your prediction for opponent move"


# a reproducible RNG seeded from the given parts; hash() is salted per
# process and can't be used for this
def rng_for(*parts):
    key = "|".join(str(p) for p in parts)
    return random.Random(int(hashlib.sha256(key.encode()).hexdigest()[:16], 16))


# ── opponents ────────────────────────────────────────────────────────────────

class _Opp:
    def update(self, agent_move):
        pass


# J -> F -> M, ignoring the agent. The positive control, and the only
# opponent whose moves form a self-contained sequence -- predictable from
# the opponent's own column alone, which is what the model tends to look at
class Cycle(_Opp):
    def __init__(self, start):
        self.start, self.label = start, f"cycle-{start}"
        i = MOVES.index(start)
        self._cycle, self._step = MOVES[i:] + MOVES[:i], 0

    def next_move(self):
        m = self._cycle[self._step % 3]
        self._step += 1
        return m


# BEATS[the agent's last move]. Follows Riemer et al. Appendix C.3, not
# classical tit-for-tat -- it's really a counter/punisher
class TitForTat(_Opp):
    def __init__(self, start):
        self.start, self.label = start, f"tft-{start}"
        self._next = start

    def next_move(self):
        return self._next

    def update(self, m):
        if m in MOVES:
            self._next = BEATS[m]


# copies the agent's last move. Same cross-stream lookup as tft, one step
# easier -- which is what makes the pair diagnostic
class Mirror(_Opp):
    def __init__(self, start):
        self.start, self.label = start, f"mirror-{start}"
        self._next = start

    def next_move(self):
        return self._next

    def update(self, m):
        if m in MOVES:
            self._next = m


# no rule at all -- the falsifier. Nothing in the history predicts the next
# move, so 33.3% is a hard ceiling. If the verbs still separate here they're
# changing how confident the model sounds rather than what it predicts,
# which is a different claim from the one the ordering hypothesis makes.
# `fixed` was dropped to make room for this: it was a floor nobody failed,
# and this cell is the one that can actually falsify something.
class RandomOpp(_Opp):
    def __init__(self, start, rng):
        self.start, self.label = start, f"random-{start}"
        self._rng = rng
        self._first = True

    def next_move(self):
        if self._first:
            self._first = False
            return self.start
        return self._rng.choice(MOVES)


# constructs the opponent for a given kind
def make_opponent(kind, start, rng=None):
    if kind == "random":
        return RandomOpp(start, rng or random.Random(0))
    cls = {"cycle": Cycle, "tft": TitForTat, "mirror": Mirror}.get(kind)
    if cls is None:
        raise ValueError(f"unknown opponent {kind!r}")
    return cls(start)


# a correctly-played transcript: random agent moves, opponent by its rule.
# Determined entirely by (kind, seed), so every verb and every level in the
# same cell reads an identical document
def make_script(kind, seed, rounds):
    rng = rng_for("script", kind, seed, config.LABEL_SCHEME)
    start = rng.choice(MOVES)
    # The random opponent draws from its own stream so the agent's moves
    # are unaffected by which opponent is in play.
    opp = make_opponent(kind, start,
                        rng_for("randopp", kind, seed, config.LABEL_SCHEME))
    hist = []
    for _ in range(rounds):
        om = opp.next_move()
        am = rng.choice(MOVES)
        opp.update(am)
        hist.append({"model": am, "opponent": om,
                     "outcome": outcome(am, om), "scripted": True})
    return hist


# ── history ──────────────────────────────────────────────────────────────────

# renders the round-by-round history. Opponent-first by default, so the cue
# completes the field that comes last in each round (Riemer et al. Figure
# 3, Partner First). The cue is the final line of the prompt, and with the
# opponent leading, every round in the document opens with "Opponent move:
# X" -- so the cue is just the next instance of a shape the document has
# already shown N times. Agent-first would leave the cue opening a round in
# a position the history never actually takes.
def format_history(hist, agent_first=False, feedback=False):
    if not hist:
        return "No rounds played yet."
    out = []
    for i, r in enumerate(hist):
        pair = ([(AGENT_LABEL, r["model"]), (OPPONENT_LABEL, r["opponent"])]
                if agent_first else
                [(OPPONENT_LABEL, r["opponent"]), (AGENT_LABEL, r["model"])])
        lines = [f"Round {i + 1}"] + [f"{k}: {v}" for k, v in pair]
        if feedback and r.get("prediction"):
            verdict = "Right" if r["prediction"] == r["opponent"] else "Wrong"
            lines.append(f"{PRED_LABEL}: {r['prediction']} - {verdict}")
        out.append("\n".join(lines))
    return "\n".join(out)


def rules_block(total_rounds):
    beats = ", ".join(f"{w} beats {l}" for l, w in BEATS.items())
    return (f"You are playing {total_rounds} rounds against the same opponent.\n"
            f"Each round you both pick one of: {MOVE_LIST}.\n"
            f"{beats}. Same pick is a tie.\n"
            f"A win scores +1, a loss -1, a tie 0. Win as many rounds as you can.")


# ── metrics ──────────────────────────────────────────────────────────────────

def outcome(a, o):
    return "tie" if a == o else ("win" if BEATS[o] == a else "lose")


def score(oc):
    return {"win": 1, "tie": 0, "lose": -1}[oc]


# what simple rules would predict for the round after `hist`. Stored per
# row so no accuracy figure gets read without them -- `opp_last` scores 0
# on switch rounds by construction, which is the test that exposed an
# earlier fake 97.7%.
def baselines(hist):
    if not hist:
        return {}
    pa, po = hist[-1]["model"], hist[-1]["opponent"]
    counts = {m: sum(1 for r in hist if r["opponent"] == m) for m in MOVES}
    return {"opp_last": po, "own_last": pa,
            "modal": max(MOVES, key=lambda m: (counts[m], m)),
            "cycle_rule": MOVES[(MOVES.index(po) + 1) % 3],
            "mirror_rule": pa,
            "tft_rule": BEATS[pa],
            # random has no rule; the key exists so runner.py can look it up
            # uniformly and store NULL rather than crashing.
            "random_rule": None}
