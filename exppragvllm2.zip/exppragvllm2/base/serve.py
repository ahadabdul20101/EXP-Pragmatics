#!/usr/bin/env python3
# serve.py — start a vLLM server, wait for it, then run the experiment.
#
# This is the Condor entry point. main.py assumes a server is already up, so
# something has to start one; doing it here keeps the two concerns apart and
# means main.py can also be pointed at a server started by hand.
#
# Any arguments are passed straight through:
#   python3 serve.py --yes --opponents cycle --tag cycle

import os
import subprocess
import sys
import time
import urllib.request

import config

SERVER_LOG = "server.log"


# prints the tail of the server log so a failure is visible in the job output
def show_server_log(tail=5000):
    """Print the end of the server log so a failure is visible in the job's
    .out rather than only in a file that may not be transferred back."""
    try:
        with open(SERVER_LOG) as f:
            text = f.read()
        print(f"\n===== SERVER LOG (last {tail} chars) =====\n")
        print(text[-tail:])
    except Exception as e:
        print(f"could not read {SERVER_LOG}: {e}")


# launches the vLLM server as a subprocess, logging its output to a file
def start_server():
    cmd = [
        sys.executable, "-m", "vllm.entrypoints.openai.api_server",
        "--model", config.VLLM_MODEL_PATH,
        "--served-model-name", config.VLLM_SERVED_NAME,
        "--tensor-parallel-size", "1",
        "--max-model-len", str(config.VLLM_MAX_MODEL_LEN),
        "--gpu-memory-utilization", str(config.VLLM_GPU_MEM_UTIL),
        "--port", str(config.VLLM_PORT),
    ]
    # Any arm that scores logprobs needs this: vLLM rejects a request asking
    # for more logprobs than the server was started with.
    if config.SCORES_LOGPROBS:
        cmd += ["--max-logprobs", str(config.VLLM_MAX_LOGPROBS)]
    print("  launching:", " ".join(cmd), flush=True)
    # The server's output goes to a FILE, not a pipe. A pipe holds only ~64KB
    # and once full the server blocks forever trying to write to it, which
    # looks exactly like "the server never started".
    log = open(SERVER_LOG, "w")
    return subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
                            text=True), log


# polls /v1/models until the server answers, the process dies, or time runs out
def wait_for_server(proc, log):
    url = f"http://{config.VLLM_HOST}:{config.VLLM_PORT}/v1/models"
    start, step = time.time(), 5

    while time.time() - start < config.VLLM_STARTUP_TIMEOUT_S:
        time.sleep(step)
        if proc.poll() is not None:
            log.flush()
            print(f"SERVER EXITED with code {proc.returncode} "
                  f"after {int(time.time() - start)}s")
            show_server_log()
            return False
        try:
            urllib.request.urlopen(url, timeout=5)
            print(f"SERVER READY after {int(time.time() - start)}s", flush=True)
            return True
        except Exception:
            pass
        elapsed = int(time.time() - start)
        if elapsed % 60 < step:
            print(f"  still waiting... {elapsed}s", flush=True)

    log.flush()
    print(f"SERVER NEVER CAME UP after {config.VLLM_STARTUP_TIMEOUT_S}s")
    show_server_log()
    return False


# sets up the environment, starts the server, then hands off to main.py
def main():
    # vLLM lives in scratch, not site-packages.
    if config.VLLM_PYLIBS and config.VLLM_PYLIBS not in sys.path:
        sys.path.insert(0, config.VLLM_PYLIBS)
    os.environ["PYTHONPATH"] = config.VLLM_PYLIBS
    # Condor hands out GPU UUIDs that int() rejects.
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    proc, log = start_server()
    try:
        if not wait_for_server(proc, log):
            sys.exit(1)
        # Imported only after the server is up, so a startup failure does not
        # get tangled with an import error.
        import main as experiment
        sys.argv = ["main.py"] + sys.argv[1:]
        sys.exit(experiment.main() or 0)
    finally:
        print("\n  shutting down vLLM server ...", flush=True)
        proc.terminate()
        try:
            proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()


if __name__ == "__main__":
    main()
