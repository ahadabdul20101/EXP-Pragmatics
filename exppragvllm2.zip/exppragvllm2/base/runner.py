# runner.py  (arm: base)
# One cell = (verb, level, opponent, seed). Every cell reads the SAME scripted
# transcript for its (opponent, seed), so verbs can be compared round by round
# rather than as group means.
#
# Prediction only. notemp2 asked a second question each round -- what do you
# play -- which is the belief-to-action gap. The verb manipulation is about
# prediction, and the action probe would double every call, so it is not asked
# here. Nothing is played: the transcript is fixed in advance either way.

import config
import database
import game
import prompts
import scoring


# a fresh result row, with every unfilled column left NULL rather than 0
def _row(**kw):
    """Every column starts NULL, so a column this arm does not fill stays
    empty rather than silently defaulting to 0."""
    base = {n: None for n, _ in database.COLUMNS}
    base.update({"arm": config.ARM, "model_kind": config.MODEL_KIND,
                 "parse_failed": 0})
    base.update(kw)
    return base


# plays out one (form, verb, level, opponent, seed) cell and scores it on
# the scheduled rounds
def run_cell(form, verb, level, opponent, seed):
    total = config.TOTAL_ROUNDS
    script = game.make_script(opponent, seed, total)
    scheduled = set(config.probe_rounds(total))
    hist, records = [], []

    for i in range(total):
        rnd = i + 1
        opp_move = script[i]["opponent"]

        # Round 1 has no history to predict from, and on a
        # generating arm the schedule thins out after the belief
        # curve has flattened.
        if rnd not in scheduled:
            hist.append(script[i])
            continue

        prompt = prompts.build_prediction(hist, level, total, form, verb,
                                          feedback=config.FEEDBACK)
        probs, cov, top = scoring.move_distribution(prompt)
        pred = scoring.argmax_move(probs)

        b = game.baselines(hist)
        rule = b.get(f"{opponent}_rule")
        records.append(_row(
            form=form, verb=verb,
            level_name=prompts.level_name(verb), task_level=level,
            question=prompts.ask(form, verb, rnd),
            opponent=opponent, seed=seed, round_num=rnd,
            truth=opp_move, prediction=pred,
            prediction_correct=int(pred == opp_move),
            switched=int(bool(hist) and opp_move != hist[-1]["opponent"]),
            opponent_move=opp_move, model_move=script[i]["model"],
            b_opp_last=int(b["opp_last"] == opp_move),
            b_own_last=int(b["own_last"] == opp_move),
            b_modal=int(b["modal"] == opp_move),
            # random has no rule, so this stays NULL there rather than
            # pretending a 33% baseline is a rule.
            b_true_rule=(int(rule == opp_move) if rule is not None else None),
            p_pred=probs[pred], pred_entropy=scoring.entropy(probs),
            pred_coverage=cov, pred_margin=scoring.margin(probs),
            p_j=probs[game.MOVES[0]], p_f=probs[game.MOVES[1]],
            p_m=probs[game.MOVES[2]],
            top_logprobs=scoring.dump_top(top),
            attempts=1, no_answer_line=0, truncated=0))

        hist.append(script[i])

    return records
