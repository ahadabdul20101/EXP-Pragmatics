# scoring.py
# One HTTP call gives one distribution over the move labels. Nothing is
# generated beyond a single token and nothing is parsed out of prose, so a
# round can never "fail to parse" and truncation cannot happen.
#
# Prefix matching is needed for the "words" scheme. With J/F/M or R/P/S the
# model's next token is the whole answer (" J", " R"). With Rock/Paper/Scissors
# it may not be: the server can return " Sc" as the top candidate. So matching
# is by prefix -- a returned token is attributed to a move if the move name
# starts with it. game.py asserts the three moves have distinct first letters,
# which makes that unambiguous.
#
# One consequence worth knowing: coverage here is the mass on moves found
# within the top-k the server returns, not over the whole vocabulary. A move
# missing from the top-k scores as 0, though its true probability is below the
# missing mass. With k=20 and three single-letter candidates that is a
# formality, but it means these coverage numbers are comparable to notemp2's
# and not to a full-softmax implementation.

import json
import math
import sys
import time
import urllib.error
import urllib.request

import config
import game

MOVES = game.MOVES

_ENDPOINT = f"http://{config.VLLM_HOST}:{config.VLLM_PORT}/v1/completions"

low_coverage_calls = 0
COVERAGE_WARN = 0.90

_STUB = False


# switches every call in this module to the deterministic fake distribution
def use_stub():
    """Fake the model so the pipeline runs without a GPU. Distributions are
    hashed from the prompt, so a dry run is deterministic and assertable."""
    global _STUB
    _STUB = True


# a distribution hashed from the prompt text, standing in for a real call
def _stub_distribution(prompt):
    import hashlib
    digest = hashlib.sha256(prompt.encode()).digest()
    weights = [1 + digest[i] for i in range(len(MOVES))]
    total = float(sum(weights))
    probs = {m: weights[i] / total for i, m in enumerate(MOVES)}
    top = {f" {m}": math.log(p * 0.9) for m, p in probs.items()}
    top["\n"] = math.log(0.1)
    return probs, 0.9, top


# sends the payload to the vLLM completions endpoint, retrying on failure
def _post(payload):
    req = urllib.request.Request(
        _ENDPOINT, data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    last = None
    for attempt in range(config.RETRY_MAX):
        try:
            with urllib.request.urlopen(req,
                                        timeout=config.REQUEST_TIMEOUT_S) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}: {e.read().decode(errors='replace')[:300]}"
        except Exception as e:
            last = repr(e)
        time.sleep(2.0 * (attempt + 1))
    raise RuntimeError(
        f"vLLM request failed after {config.RETRY_MAX} attempts: {last}")


# which move a returned token belongs to, if any
def _match(token):
    """Which move does this returned token belong to, if any?

    " J"  -> J          " Sc" -> Scissors (first token of a multi-token word)
    " Jo" -> None       ""    -> None     (empty prefixes everything)
    """
    t = token.strip().lower()
    if not t:
        return None
    for m in MOVES:
        if m.lower().startswith(t):
            return m
    return None


# scores the prompt and returns the next-token distribution over the moves
def move_distribution(prompt):
    """Next-token distribution restricted to the move labels.

    Returns (probs, coverage, top):
      probs    -- over MOVES, renormalised to sum to 1
      coverage -- RAW mass that landed on the moves. Read this before any
                  accuracy figure: near 1.0 means the cue worked.
      top      -- the raw {token: logprob} dict as returned. Stored per row,
                  which is what makes the coverage question answerable from the
                  database rather than needing a separate diagnostic job.
    """
    global low_coverage_calls

    if _STUB:
        return _stub_distribution(prompt)

    data = _post({
        "model": config.VLLM_SERVED_NAME,
        "prompt": prompt,
        "max_tokens": 1,
        "temperature": 0.0,
        "logprobs": config.TOP_LOGPROBS,
    })

    try:
        top = data["choices"][0]["logprobs"]["top_logprobs"][0]
    except (KeyError, IndexError, TypeError) as e:
        print(f"    [scoring] unexpected response shape: {e}",
              file=sys.stderr, flush=True)
        raise

    raw = {m: 0.0 for m in MOVES}
    for token, logprob in top.items():
        m = _match(token)
        if m is not None:
            raw[m] += math.exp(logprob)

    coverage = sum(raw.values())
    if coverage < COVERAGE_WARN:
        low_coverage_calls += 1

    if coverage <= 0.0:
        uniform = 1.0 / len(MOVES)
        return {m: uniform for m in MOVES}, 0.0, top

    return {m: raw[m] / coverage for m in MOVES}, coverage, top


# serializes a top-k dict for storage, highest logprob first
def dump_top(top, limit=None):
    """Serialise a top-k dict for the DB: highest logprob first, rounded.

    This is what coverage.py reads to say WHERE the non-move mass went, per
    verb and per round band, without another GPU job.
    """
    if not top:
        return None
    limit = limit or config.TOP_LOGPROBS
    ordered = sorted(top.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    return json.dumps([[tok, round(lp, 5)] for tok, lp in ordered])


# ── selection ────────────────────────────────────────────────────────────────

# highest-probability move, ties broken by label so it is reproducible
def argmax_move(probs):
    """Highest-probability move; ties broken by label so it is reproducible."""
    return max(MOVES, key=lambda m: (probs[m], m))


# ── diagnostics ──────────────────────────────────────────────────────────────

# entropy of the distribution, in bits
def entropy(probs):
    """Bits. 0 = certain, log2(3) ~= 1.585 = no opinion at all."""
    return -sum(p * math.log2(p) for p in probs.values() if p > 0)


# how much more likely the top move was than the runner-up
def margin(probs):
    """Top probability minus runner-up: how decisive the choice was."""
    ordered = sorted(probs.values(), reverse=True)
    return ordered[0] - ordered[1]
