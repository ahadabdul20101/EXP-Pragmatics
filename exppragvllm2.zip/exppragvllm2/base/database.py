# database.py
# One row per (verb, level, opponent, seed, round). Auto-numbered files, so a
# rerun never overwrites a result.
#
# The schema is shared by all four arms. Columns that do not apply to an arm
# are NULL there -- base and teacherforcing leave the generation columns empty,
# the generating arms leave the probability columns empty -- which lets one
# reader put arms side by side.

import os
import sqlite3

import config

COLUMNS = [
    ("arm", "TEXT"), ("model_kind", "TEXT"),
    # The shape of the ask. vllm1 had only questions, so it could not say
    # whether its verb effect came from the verb or from the interrogative.
    #   question | statement | statement_n | taskverb
    ("form", "TEXT"),
    ("verb", "TEXT"), ("level_name", "TEXT"), ("task_level", "TEXT"),
    ("question", "TEXT"),
    ("opponent", "TEXT"), ("seed", "INTEGER"), ("round_num", "INTEGER"),

    ("truth", "TEXT"), ("prediction", "TEXT"), ("prediction_correct", "INTEGER"),
    ("switched", "INTEGER"),
    ("opponent_move", "TEXT"), ("model_move", "TEXT"),

    # what four trivial rules would have answered, so accuracy is never read
    # alone. opp_last scores 0 on switch rounds by construction.
    ("b_opp_last", "INTEGER"), ("b_own_last", "INTEGER"),
    ("b_modal", "INTEGER"), ("b_true_rule", "INTEGER"),

    # ── teacher-forced arms only ─────────────────────────────────────────────
    ("p_pred", "REAL"), ("pred_entropy", "REAL"), ("pred_coverage", "REAL"),
    ("pred_margin", "REAL"),
    ("p_j", "REAL"), ("p_f", "REAL"), ("p_m", "REAL"),
    # the top-k tokens with logprobs, as JSON. This is what makes "where did
    # the missing coverage go" answerable from the database instead of needing
    # a separate diagnostic job.
    ("top_logprobs", "TEXT"),

    # ── generating arms only ─────────────────────────────────────────────────
    ("attempts", "INTEGER"),
    # 1 when no answer could be read honestly after every attempt, so the move
    # came from the permissive fallback and the row is a guess.
    ("no_answer_line", "INTEGER"),
    ("truncated", "INTEGER"),
    # 1 when the first stage hit the token cap and the answer came from the
    # forced-exit call instead. vllm1 had no second stage and silently scored
    # the unfinished reasoning: those rows read 29-33% against 60-92%.
    ("forced_exit", "INTEGER"),
    ("n_gen_chars", "INTEGER"),
    # Which parser pass produced the answer: 1 anchored labelled line,
    # 2 inline label in the tail, 3 permissive fallback. vllm1's predict()
    # returned this and it was dropped, because it was missing from this list.
    ("parse_tier", "INTEGER"),
    # Where the answer line sits as a fraction of the response. Near 1.0 is a
    # conclusion; 0.4 is the model restating the history with the real answer
    # never written. This is what made the vllm1 failure diagnosable.
    ("answer_pos", "REAL"),
    # The full first-stage text, ALWAYS, never sliced. `reasoning` mirrors it
    # rather than holding a prefix, so a parser bug can be repaired offline
    # instead of costing a rerun.
    ("raw_response", "TEXT"), ("reasoning", "TEXT"), ("answer_line", "TEXT"),
    ("raw_exit", "TEXT"),
    # The model's stated belief about the opponent's strategy, verbatim, on
    # the rulecarry arm. Scored offline by keyword, so changing the scoring
    # never needs GPU time.
    ("rule_stated", "TEXT"),

    ("parse_failed", "INTEGER"),
]


def next_path(tag):
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    n = 1
    while True:
        p = os.path.join(config.RESULTS_DIR,
                         f"{config.db_prefix()}_{tag}_run{n}.db")
        if not os.path.exists(p):
            return p
        n += 1


def connect(path):
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("CREATE TABLE IF NOT EXISTS rounds (id INTEGER PRIMARY KEY, "
                 + ", ".join(f"{n} {t}" for n, t in COLUMNS) + ")")
    conn.execute("CREATE TABLE IF NOT EXISTS run_meta "
                 "(key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cell ON rounds "
                 "(arm, opponent, verb, task_level, seed)")
    # Pairing key: every verb is compared against `say` at the same
    # (opponent, level, seed, round), so this index is what the reader leans on.
    conn.execute("CREATE INDEX IF NOT EXISTS idx_pair ON rounds "
                 "(opponent, task_level, seed, round_num)")
    # Rows whose answer came from a real answer line. Anything else is a guess
    # from a truncated response. Report against this, not `rounds`.
    conn.execute("CREATE VIEW IF NOT EXISTS clean AS "
                 "SELECT * FROM rounds "
                 "WHERE COALESCE(no_answer_line, 0) = 0 "
                 "  AND prediction IS NOT NULL "
                 # A reply that hit the token cap and was NOT
                 # rescued by the forced-exit call has no
                 # conclusion in it. vllm1 scored those anyway and
                 # they came back at chance: 29.3% on cycle
                 # against 91.9% for untruncated rows.
                 "  AND NOT (COALESCE(truncated, 0) = 1 "
                 "           AND COALESCE(forced_exit, 0) = 0)")
    conn.commit()
    return conn


def write_meta(conn, meta):
    conn.executemany(
        "INSERT OR REPLACE INTO run_meta (key, value) VALUES (?,?)",
        [(k, str(v)) for k, v in meta.items()])
    conn.commit()


def insert(conn, records):
    names = [n for n, _ in COLUMNS]
    conn.executemany(
        f"INSERT INTO rounds ({', '.join(names)}) "
        f"VALUES ({', '.join('?' * len(names))})",
        [tuple(r.get(n) for n in names) for r in records])
    conn.commit()
    return len(records)


def count(conn):
    return conn.execute("SELECT COUNT(*) FROM rounds").fetchone()[0]
