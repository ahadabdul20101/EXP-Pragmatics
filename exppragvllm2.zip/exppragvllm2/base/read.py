#!/usr/bin/env python3
# read.py — the main reader. Pure stdlib, runs on the login node.
#
#   python3 read.py --dir ~/expprag/exppragvllm/results/base
#   python3 read.py --dir ... --opponents cycle random
#
# Tables come in the order they can be trusted. An accuracy figure read before
# the health and coverage tables is not interpretable, which is why they come
# first and why this refuses to print accuracy without them.
#
# Use coverage.py for the verb x round-band coverage study.

import argparse
import glob
import json
import math
import os
import os as _os
import sqlite3
from collections import Counter, defaultdict

MOVES = ("J", "F", "M")
LEVEL_ORDER = ["high", "mid", "low", "neutral", "task", "none"]
REFERENCE = _os.environ.get("REFERENCE", "none")
# vllm1 used `say`. It is NOT neutral in the teacher-forced arms: it
# carries <|im_end|> at 0.316 mean probability against 0.165-0.204
# for the epistemic verbs, and it reads M exactly 0.0% on cycle,
# where a third of the truth is M. A control with a degenerate answer
# distribution is not a baseline. `none` had the highest coverage of
# any condition (0.825 base, 0.730 relationderivation) and led
# accuracy at every round band, so it is the reference now.
# REFERENCE=say restores the old behaviour for comparison.


def load(paths):
    rows = []
    for p in paths:
        conn = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            rows += [dict(r) for r in conn.execute("SELECT * FROM rounds")]
        except sqlite3.Error:
            pass
        conn.close()
    return rows


def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def sd(xs):
    xs = [x for x in xs if x is not None]
    if len(xs) < 2:
        return 0.0
    m = sum(xs) / len(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))


def f(v, w=6):
    return f"{v:{w}.1f}" if isinstance(v, (int, float)) else f"{'—':>{w}}"


def cell(xs, key, scale=100, w=10, dp=1):
    """One table cell, em dash when the column is empty OR
    entirely NULL. A NULL column is not an error: `random` has no
    policy so rule_correct is NULL there by design, and
    pred_coverage is NULL wherever the arm generates."""
    m = mean([x[key] for x in xs]) if xs else None
    return (f"{scale * m:>{w}.{dp}f}" if m is not None
            else f"{'—':>{w}}")


def group(rows, *keys):
    out = defaultdict(list)
    for r in rows:
        out[tuple(r[k] for k in keys)].append(r)
    return out


def verbs_of(rows):
    seen = {}
    for r in rows:
        seen.setdefault(r["verb"], r["level_name"])
    # An unknown or missing level sorts last rather than raising. A
    # verb added to prompts.VERBS with a new level name used to take
    # down table 1 of every reader with `None is not in list`.
    def rank(v):
        lv = seen[v]
        return (LEVEL_ORDER.index(lv) if lv in LEVEL_ORDER
                else len(LEVEL_ORDER), v)

    return sorted(seen, key=rank)


def opps_of(rows):
    order = ["cycle", "mirror", "tft", "random", "counter"]
    got = {r["opponent"] for r in rows}
    return [o for o in order if o in got] + sorted(got - set(order))


def clean(rows):
    """Rows safe to average: a real answer was produced, and for the generating
    arms it came from a real answer line rather than the permissive fallback."""
    return [r for r in rows
            if r["prediction"] is not None and not (r["no_answer_line"] or 0)]


# ── 0-2: can anything below be trusted? ──────────────────────────────────────

def t0_health(rows):
    print("\n0. HEALTH  -- READ THIS FIRST")
    print("   In an earlier harness 938 of 3,000 instruct predictions (31%)")
    print("   came back with no answer line and were resolved by taking the")
    print("   last move token, which inverts on negation and scored at")
    print("   chance. That is why this table comes before any accuracy.\n")
    generating = any(r["raw_response"] for r in rows)
    for o in opps_of(rows):
        sub = [r for r in rows if r["opponent"] == o]
        n = len(sub)
        cl = len(clean(sub))
        line = f"   {o:<8} {n:6d} rows   {100*cl/max(1,n):5.1f}% usable"
        if generating:
            tr = sum(1 for r in sub if r["truncated"])
            nal = sum(1 for r in sub if r["no_answer_line"])
            at = mean([r["attempts"] for r in sub])
            line += (f"   truncated {100*tr/max(1,n):5.1f}%"
                     f"   no answer line {100*nal/max(1,n):5.1f}%"
                     f"   attempts {at:.2f}" if at else "")
        else:
            cov = mean([r["pred_coverage"] for r in sub])
            low = sum(1 for r in sub if (r["pred_coverage"] or 1) < 0.90)
            line += (f"   coverage {cov:.3f}"
                     f"   below floor {100*low/max(1,n):5.1f}%")
        print(line)
    print()


def t1_coverage(rows):
    sub = [r for r in rows if r["pred_coverage"] is not None]
    if not sub:
        return
    print("1. COVERAGE by verb  (teacher-forced arms)")
    print("   Mass on the move labels at the answer position. A verb that")
    print("   differs HERE is producing a formatting effect, not an epistemic")
    print("   one. coverage.py breaks this down by round band.\n")
    opps = opps_of(sub)
    g = group(sub, "verb", "opponent")
    print(f"   {'verb':<11} {'level':<8}" + "".join(f"{o:>10}" for o in opps))
    for v in verbs_of(sub):
        lvl = next(r["level_name"] for r in sub if r["verb"] == v)
        cells = "".join(
            f"{mean([x['pred_coverage'] for x in g[(v, o)]]):>10.3f}"
            if g[(v, o)] else f"{'—':>10}" for o in opps)
        print(f"   {v:<11} {lvl:<8}{cells}")
    per = [mean([x["pred_coverage"] for x in group(sub, "verb")[(v,)]])
           for v in verbs_of(sub)]
    print(f"\n   spread across verbs: {max(per) - min(per):.3f}\n")


def t2_parse(rows):
    sub = [r for r in rows if r["raw_response"]]
    if not sub:
        return
    print("2. PARSE AND TRUNCATION by verb  (generating arms)")
    print("   Accuracy is computed over parsed rows only. A verb that refuses")
    print("   more often has its accuracy measured on a different and")
    print("   probably easier subset, so these read together.\n")
    opps = opps_of(sub)
    g = group(sub, "verb", "opponent")
    for label, key in (("parsed %", "ok"), ("truncated %", "truncated")):
        print(f"   {label}")
        print(f"      {'verb':<11}" + "".join(f"{o:>10}" for o in opps))
        for v in verbs_of(sub):
            cells = ""
            for o in opps:
                cell = g[(v, o)]
                if not cell:
                    cells += f"{'—':>10}"
                    continue
                if key == "ok":
                    val = 100 * len(clean(cell)) / len(cell)
                else:
                    val = 100 * sum(r["truncated"] or 0
                                    for r in cell) / len(cell)
                cells += f"{val:>10.1f}"
            print(f"      {v:<11}{cells}")
        print()


# ── 3-5: the result ──────────────────────────────────────────────────────────

def t3_accuracy(rows):
    print("3. ACCURACY (%) over usable rows, with the trivial baselines")
    print("   On random, 33.3 is a hard ceiling: nothing predicts the next")
    print("   move. persist and own-last need no pattern at all, so accuracy")
    print("   at or below them is not prediction.\n")
    cl = clean(rows)
    opps = opps_of(cl)
    for lv in sorted({r["task_level"] for r in cl}):
        print(f"   task level {lv}")
        print(f"      {'verb':<11} {'level':<8}"
              + "".join(f"{o:>10}" for o in opps))
        g = group([r for r in cl if r["task_level"] == lv], "verb", "opponent")
        for v in verbs_of(cl):
            lname = next(r["level_name"] for r in cl if r["verb"] == v)
            cells = "".join(
                f"{100*mean([x['prediction_correct'] for x in g[(v, o)]]):>10.1f}"
                if g[(v, o)] else f"{'—':>10}" for o in opps)
            print(f"      {v:<11} {lname:<8}{cells}")
        print()
    print(f"      {'baseline':<20}" + "".join(f"{o:>10}" for o in opps))
    for key, lab in (("b_opp_last", "persist"), ("b_own_last", "own last"),
                     ("b_modal", "modal"), ("b_true_rule", "true rule")):
        cells = ""
        for o in opps:
            # A baseline is a property of the transcript, not of a verb, so it
            # is counted once per (seed, level, round) rather than 12 times.
            seen = {(r["seed"], r["task_level"], r["round_num"]): r[key]
                    for r in cl if r["opponent"] == o and r[key] is not None}
            m = mean(list(seen.values()))
            cells += f"{100*m:>10.1f}" if m is not None else f"{'—':>10}"
        print(f"      {lab:<20}{cells}")
    print()


def t3b_form(rows):
    """Does the SHAPE of the ask matter more than the word inside it?

    This is the table vllm1 could not produce. Eleven of its twelve conditions
    were questions, so the 0.20-0.25 coverage spread it found across verbs
    could not be attributed: it might have been the verbs, or it might have
    been that ten of them sat inside one interrogative frame and two did not.

    Read the three columns together:

      coverage   the vllm1 effect was here, not in accuracy. A form that
                 moves coverage while leaving accuracy flat is changing the
                 FORMAT of the answer.
      accuracy   if this moves and coverage does not, the form is changing
                 what the model believes, which would be the real result.
      spread     the largest gap between any two verbs INSIDE this form. If
                 the between-form gap is smaller than the within-form spread,
                 form is not organising the data either.
    """
    cl = clean(rows)
    forms = sorted({(r.get("form") or "question") for r in cl})
    if len(forms) < 2:
        return
    print("3b. BY FORM  (the shape of the ask, pooled over verbs)")
    print("    taskverb/predict is byte-identical to vllm1's `task`")
    print("    condition, which is the anchor between the two runs.\n")
    opps = opps_of(cl)
    for lv in sorted({r["task_level"] for r in cl}):
        sub = [r for r in cl if r["task_level"] == lv]
        if not sub:
            continue
        print(f"    {lv}")
        print(f"      {'form':<13}{'n':>7}{'cov':>8}{'spread':>8}"
              + "".join(f"{o:>10}" for o in opps))
        for fm in forms:
            rs = [r for r in sub if (r.get("form") or "question") == fm]
            if not rs:
                continue
            per = [mean([x["prediction_correct"]
                         for x in group(rs, "verb")[(v,)]])
                   for v in {r["verb"] for r in rs}]
            per = [100 * x for x in per if x is not None]
            spread = max(per) - min(per) if len(per) > 1 else None
            cov = mean([r["pred_coverage"] for r in rs])
            g = group(rs, "opponent")
            cells = "".join(cell(g[(o,)], "prediction_correct") for o in opps)
            print(f"      {fm:<13}{len(rs):>7}"
                  f"{f(cov, 8) if cov is None else format(cov, '>8.3f')}"
                  f"{f(spread, 8)}{cells}")
        print()

def t4_levels(rows):
    print("4. BY EPISTEMIC LEVEL  (the ordering test)")
    print("   The hypothesis predicts high > mid > low.")
    print()
    print("   RANDOM IS THE FALSIFIER. There is nothing to predict there, so")
    print("   an ordering that also holds on random is a confidence style and")
    print("   not prediction.\n")
    cl = clean(rows)
    opps = opps_of(cl)
    g = group(cl, "level_name", "opponent")
    print(f"      {'level':<11}" + "".join(f"{o:>10}" for o in opps))
    for lv in LEVEL_ORDER:
        if not any(r["level_name"] == lv for r in cl):
            continue
        cells = "".join(
            f"{100*mean([x['prediction_correct'] for x in g[(lv, o)]]):>10.1f}"
            if g[(lv, o)] else f"{'—':>10}" for o in opps)
        print(f"      {lv:<11}{cells}")
    print()

    print("   within-level vs between-level spread")
    print("   If verbs inside a level differ from each other as much as the")
    print("   levels differ, verb identity is organising the data and")
    print("   epistemic level is not.\n")
    for o in opps:
        sub = [r for r in cl if r["opponent"] == o
               and r["level_name"] in ("high", "mid", "low")]
        if not sub:
            continue
        # Only the levels actually present. A --verbs subset, or a form that
        # defines no neutral verb, leaves a level empty, and mean() then
        # returns None. vllm1 crashed here for exactly that reason.
        pv = {v: mean([x["prediction_correct"]
                       for x in group(sub, "verb")[(v,)]])
              for v in {r["verb"] for r in sub}}
        pv = {v: 100 * m for v, m in pv.items() if m is not None}
        pl = {}
        for l in ("high", "mid", "low"):
            m = mean([x["prediction_correct"]
                      for x in group(sub, "level_name")[(l,)]])
            if m is not None:
                pl[l] = 100 * m
        spans = []
        for l in pl:
            vs = [pv[r["verb"]] for r in sub
                  if r["level_name"] == l and r["verb"] in pv]
            if vs:
                spans.append(max(vs) - min(vs))
        if not spans or len(pl) < 2:
            print(f"      {o:<9} not enough levels present to compare")
            continue
        within = max(spans)
        between = max(pl.values()) - min(pl.values())
        verdict = ("verb identity dominates" if within > between
                   else "level dominates")
        print(f"      {o:<9} within {within:5.1f}   between {between:5.1f}"
              f"   -> {verdict}")
    print()


def _paired(rows_a, rows_b, key):
    """d and t for two matched sets. `key` must uniquely identify a probe.

    THE KEY MUST BE UNIQUE PER SET, and getting that wrong is not a small
    error. vllm1's relationderivation reader keyed on (seed, round_num) while
    three measurement modes sat in one directory, so several reference rows
    shared every key and the dict kept whichever loaded last. Every verb from
    all three modes was then differenced against a teacherforcing row: it
    reported d up to +25.0 with t = 11.2 where the group means differed by 4,
    and the pair count gave it away at 627 where it should have been 297.
    """
    ref = {key(r): r for r in rows_b}
    if len(ref) != len(rows_b):
        return None, None, 0, "reference key is not unique -- modes pooled?"
    d = [r["prediction_correct"] - ref[key(r)]["prediction_correct"]
         for r in rows_a if key(r) in ref]
    if not d:
        return None, None, 0, "no matching pairs"
    s = sd(d)
    t = (sum(d) / len(d)) / (s / math.sqrt(len(d))) if s else 0.0
    return 100 * sum(d) / len(d), t, len(d), ""


def t5_paired(rows):
    print(f"5. PAIRED DIFFERENCE vs '{REFERENCE}'  (within the question form)")
    print("   Every verb sees a byte-identical history at the same round, so")
    print("   they compare round by round instead of as group means. That")
    print("   removes the variance from some rounds being harder than others.")
    print("   d is the mean per-round difference in points; |t| over ~2 is")
    print("   worth a look, ~3 is solid.")
    print()
    print("   QUESTION FORM ONLY, because the reference lives there. The")
    print("   statement and taskverb forms have no verbless condition -- a")
    print("   verbless imperative is not a sentence -- so the form contrast")
    print("   is table 5b, matched on verb instead.\n")
    cl = [r for r in clean(rows) if (r.get("form") or "question") == "question"]
    if not cl:
        return
    def key(r):
        return (r["seed"], r["round_num"])
    for o in opps_of(cl):
        for lv in sorted({r["task_level"] for r in cl}):
            sub = [r for r in cl
                   if r["opponent"] == o and r["task_level"] == lv]
            base = [r for r in sub if r["verb"] == REFERENCE]
            if not base:
                continue
            print(f"   {o} / {lv}")
            print(f"      {'verb':<11}{'pairs':>7}{'d acc':>9}{'t':>7}")
            for v in verbs_of(sub):
                if v == REFERENCE:
                    continue
                d, t, n, why = _paired([r for r in sub if r["verb"] == v],
                                       base, key)
                if why:
                    print(f"      {v:<11}{'':>7}   {why}")
                    continue
                print(f"      {v:<11}{n:>7}{d:>9.1f}{t:>7.1f}")
            print()


def t5b_form_paired(rows):
    """The form contrast, matched on verb.

    Each statement or taskverb row is differenced against the QUESTION row
    with the same verb, level, opponent, seed and round. That is the tightest
    comparison available: the two documents are byte-identical apart from the
    one line, and the line contains the same verb, so anything left is the
    shape of the ask.
    """
    cl = clean(rows)
    forms = sorted({(r.get("form") or "question") for r in cl})
    if "question" not in forms or len(forms) < 2:
        return
    print("5b. PAIRED DIFFERENCE vs the QUESTION form, matched on verb")
    print("    statement/predict against question/predict, and so on, at the")
    print("    same round of the same transcript. The verb is held, so what")
    print("    is left is whether being asked beats being told.\n")
    def key(r):
        return (r["verb"], r["seed"], r["round_num"])
    for o in opps_of(cl):
        for lv in sorted({r["task_level"] for r in cl}):
            sub = [r for r in cl
                   if r["opponent"] == o and r["task_level"] == lv]
            base = [r for r in sub
                    if (r.get("form") or "question") == "question"]
            if not base:
                continue
            printed = False
            for fm in forms:
                if fm == "question":
                    continue
                rs = [r for r in sub if (r.get("form") or "question") == fm]
                if not rs:
                    continue
                # only verbs this form actually defines
                shared = {r["verb"] for r in rs} & {r["verb"] for r in base}
                a = [r for r in rs if r["verb"] in shared]
                b = [r for r in base if r["verb"] in shared]
                d, t, n, why = _paired(a, b, key)
                if not printed:
                    print(f"    {o} / {lv}")
                    print(f"      {'form':<13}{'pairs':>7}{'d acc':>9}{'t':>7}")
                    printed = True
                if why:
                    print(f"      {fm:<13}{'':>7}   {why}")
                else:
                    print(f"      {fm:<13}{n:>7}{d:>9.1f}{t:>7.1f}")
            if printed:
                print()


# ── 6-8: shape of the learning ───────────────────────────────────────────────

def t6_bands(rows, n=10):
    print(f"6. ACCURACY BY BAND ({n} bands), per epistemic level")
    print("   Rising means the pattern is being induced from the growing")
    print("   history. On random it must stay flat at 33.3 -- if it does not,")
    print("   the transcript is not actually random.\n")
    cl = clean(rows)
    if not cl:
        return
    lo, hi = min(r["round_num"] for r in cl), max(r["round_num"] for r in cl)
    w = max(1, (hi - lo + 1) // n)
    for o in opps_of(cl):
        sub = [r for r in cl if r["opponent"] == o]
        if not sub:
            continue
        print(f"   {o}")
        heads = [f"{lo+b*w}-{min(lo+(b+1)*w-1, hi)}" for b in range(n)]
        print(f"      {'level':<9}" + "".join(f"{h:>8}" for h in heads))
        for lv in LEVEL_ORDER:
            ls = [r for r in sub if r["level_name"] == lv]
            if not ls:
                continue
            cells = ""
            for b in range(n):
                a1, b1 = lo + b * w, min(lo + (b + 1) * w - 1, hi)
                m = mean([r["prediction_correct"] for r in ls
                          if a1 <= r["round_num"] <= b1])
                cells += f"{100*m:>8.1f}" if m is not None else f"{'—':>8}"
            print(f"      {lv:<9}{cells}")
        print()


def t7_answer_ratio(rows):
    print("7. ANSWER RATIO  J / F / M")
    print("   cycle and random both play each move equally often, so a clean")
    print("   run reads near 33/33/33 there. A skew is a label bias and it")
    print("   inflates accuracy wherever it happens to match the truth.\n")
    cl = clean(rows)
    for o in opps_of(cl):
        sub = [r for r in cl if r["opponent"] == o]
        if not sub:
            continue
        print(f"   {o}")
        g = group(sub, "verb")
        for v in verbs_of(sub):
            rs = g[(v,)]
            c = Counter(r["prediction"] for r in rs)
            tot = len(rs) or 1
            print(f"      {v:<11}" + "   ".join(
                f"{m} {100*c[m]/tot:5.1f}" for m in MOVES))
        print()


def t8_seeds(rows):
    print("8. PER SEED  (accuracy %, so no average hides a split)\n")
    cl = clean(rows)
    seeds = sorted({r["seed"] for r in cl})
    if len(seeds) < 2:
        print(f"   only seed {seeds} in this run\n")
        return
    for o in opps_of(cl):
        sub = [r for r in cl if r["opponent"] == o]
        if not sub:
            continue
        print(f"   {o}")
        print(f"      {'verb':<11}" + "".join(f"{'seed '+str(s):>10}"
                                              for s in seeds))
        g = group(sub, "verb", "seed")
        for v in verbs_of(sub):
            cells = "".join(
                f"{100*mean([x['prediction_correct'] for x in g[(v, s)]]):>10.1f}"
                if g[(v, s)] else f"{'—':>10}" for s in seeds)
            print(f"      {v:<11}{cells}")
        print()


def t9_samples(rows, n=2):
    sub = [r for r in rows if r["reasoning"]]
    if not sub:
        return
    print("9. SAMPLE REASONING  (generating arms)")
    print("   The model's own working, stored per row. Two shown per verb.\n")
    shown = defaultdict(int)
    for r in sub:
        if shown[r["verb"]] >= n:
            continue
        shown[r["verb"]] += 1
        body = " ".join((r["reasoning"] or "").split())[:240]
        tag = "REFUSED" if not r["prediction"] else f"-> {r['prediction']}"
        print(f"   [{r['verb']} / {r['opponent']} r{r['round_num']}] {tag}")
        print(f"     {body}...\n")


def main():
    ap = argparse.ArgumentParser(description="exppragvllm reader")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--opponents", nargs="+", default=None)
    ap.add_argument("--bands", type=int, default=10)
    args = ap.parse_args()

    paths = sorted(glob.glob(os.path.join(args.dir, "*_run*.db")))
    if not paths:
        print(f"no databases in {args.dir}")
        return 1
    rows = load(paths)
    if args.opponents:
        rows = [r for r in rows if r["opponent"] in args.opponents]
    if not rows:
        print("no rows matched")
        return 1

    print(f"{len(rows)} rows from {len(paths)} database(s) in {args.dir}")
    arms = {(r["arm"], r["model_kind"]) for r in rows}
    print(f"arms: {sorted(arms)}")

    t0_health(rows)
    t1_coverage(rows)
    t2_parse(rows)
    t3_accuracy(rows)
    t3b_form(rows)
    t4_levels(rows)
    t5_paired(rows)
    t5b_form_paired(rows)
    t6_bands(rows, args.bands)
    t7_answer_ratio(rows)
    t8_seeds(rows)
    t9_samples(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
