#!/usr/bin/env python3
# main.py
#
#   python3 main.py --self-test                    no GPU, no server
#   python3 main.py --dry-run --yes --rounds 12 --seeds 1
#   python3 serve.py --yes --opponents cycle --tag cycle
#
# serve.py is the Condor entry point: it starts a vLLM server, waits for it,
# then calls main(). main.py assumes a server is already up, so it can also be
# pointed at one started by hand.

import argparse
import datetime
import os
import shutil
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

import config
import database
import game
import prompts
import runner


# ── self-test ────────────────────────────────────────────────────────────────

# every (form, verb) pair this arm actually runs
def _conditions():
    """Every (form, verb) pair this arm actually runs.

    prompts.conditions() is the full design; config.FORMS is what this arm
    was configured for. instructnormal drops statement_n, because a deixis
    control is worth measuring where a probe costs one token rather than 5000.
    """
    return [(f, v) for f, v in prompts.conditions() if f in config.FORMS]


# prints the prompt, the design, and a batch of consistency checks; no GPU
def self_test():
    ok = True
    print("=" * 74)
    print(f"1. THE PROMPT, in full   [arm {config.ARM} / {config.MODEL_KIND}]")
    print("=" * 74)
    h = game.make_script("tft", 1, 3)
    _p = prompts.build_prediction(h, "L0", config.TOTAL_ROUNDS,
                              "question", "predict")
    print(_p if isinstance(_p, str) else f"{_p[0]}\n---\n{_p[1]}")
    print("^^^ the next token is what gets scored\n")

    print("=" * 74)
    print("2. The line that varies")
    print("=" * 74)
    for form in config.FORMS:
        print(f"   [{form}]")
        for verb, _lvl in prompts.VERBS.items():
            if form != "question" and verb not in prompts.EPISTEMIC:
                continue
            print(f"      {prompts.level_name(verb):8s} {verb:11s} "
                  f"{prompts.ask(form, verb, 42)}")
        if form == "question":
            print(f"      {'none':8s} {'none':11s} "
                  f"{prompts.ask('question', 'none', 42)}")
    print(f"\n   task lines:")
    for lv in config.LEVELS:
        print(f"   {lv:8s} ({prompts.LEVEL_DESCRIPTIONS[lv]}) "
              f"{prompts.TASK_LINE[lv] or '(nothing)'}")
    nest, why = prompts.levels_nest()
    print(f"   {'PASS' if nest else 'FAIL'}  L3 decomposes into L1 + L2"
          f"{'' if nest else '  -- ' + why}")
    ok = ok and nest
    print()


    print("=" * 74)
    print("3. Geometry")
    print("=" * 74)
    n_cond = len(_conditions())
    for lv in config.LEVELS:
        same, why = prompts.only_the_ask_differs(h, lv, config.TOTAL_ROUNDS)
        print(f"   {'PASS' if same else 'FAIL'}  {lv}: all {n_cond} "
              f"conditions differ only in the ask"
              f"{'' if same else '  -- ' + why}")
        ok = ok and same
        one, why = prompts.ask_is_one_line(h, lv, config.TOTAL_ROUNDS)
        print(f"   {'PASS' if one else 'FAIL'}  {lv}: every ask is one line"
              f"{'' if one else '  -- ' + why}")
        ok = ok and one
        clean, why = prompts.nothing_to_copy(h, lv, config.TOTAL_ROUNDS)
        print(f"   {'PASS' if clean else 'FAIL'}  {lv}: nothing to copy beside "
              f"the cue{'' if clean else '  -- ' + why}")
        ok = ok and clean


    _doc = prompts.build_prediction(h, "L0", config.TOTAL_ROUNDS,
                                    "question", "predict")
    if not isinstance(_doc, str):
        _doc = f"{_doc[0]}\n{_doc[1]}"
    n_label = sum(1 for l in _doc.split("\n")
                  if l.startswith(f"{game.OPPONENT_LABEL}: "))
    print(f"   INFO  '{game.OPPONENT_LABEL}:' appears {n_label} times in this "
          f"history followed by a move,\n         so the cue needs no template")
    print()

    print("=" * 74)
    print("4. Scripted transcripts -- does the opponent actually vary?")
    print("=" * 74)
    print(f"   {'opponent':<9} {'agent distinct':>15} {'opp switches':>13} "
          f"{'opp ratio':>22}")
    for kind in config.OPPONENTS:
        ad = sw = 0
        ratio = Counter()
        for seed in config.SEEDS:
            s = game.make_script(kind, seed, config.TOTAL_ROUNDS)
            ad += len({r["model"] for r in s})
            sw += sum(1 for i in range(1, len(s))
                      if s[i]["opponent"] != s[i - 1]["opponent"])
            ratio.update(r["opponent"] for r in s)
        n = len(config.SEEDS)
        tot = sum(ratio.values()) or 1
        rs = " ".join(f"{m}:{100*ratio[m]/tot:4.1f}%" for m in game.MOVES)
        print(f"   {kind:<9} {ad/n:15.1f} {sw/n:13.1f} {rs:>22}")
    print(f"\n   ({config.TOTAL_ROUNDS - 1} switches possible. cycle and random")
    print("    must both read near 33/33/33 -- they play each move equally.)\n")

    print("=" * 74)
    print("5. Every condition reads the SAME history")
    print("=" * 74)
    hists = set()
    for form, verb in _conditions():
        t = prompts.build_prediction(h, "L0", config.TOTAL_ROUNDS, form, verb)
        if not isinstance(t, str):
            t = f"{t[0]}\n{t[1]}"
        hists.add(t.split("You are currently playing")[0])
    if len(hists) == 1:
        print("   PASS  identical document above the ask for every condition")
    else:
        print(f"   FAIL  {len(hists)} distinct histories")
        ok = False

    rounds = config.probe_rounds(config.TOTAL_ROUNDS)
    cells = (len(_conditions()) * len(config.LEVELS)
             * len(config.OPPONENTS) * len(config.SEEDS))
    probes = cells * len(rounds)
    print(f"\n   {len(_conditions())} conditions "
          f"({len(config.FORMS)} forms) x {len(config.LEVELS)} levels "
          f"x {len(config.OPPONENTS)} opponents x {len(config.SEEDS)} seeds")
    print(f"   {cells} cells, {len(rounds)} probe rounds each "
          f"(rounds {rounds[0]}..{rounds[-1]})")
    print(f"   {probes} probes total "
          f"({probes // max(1, len(config.OPPONENTS))} per opponent job)\n")

    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


# ── run ──────────────────────────────────────────────────────────────────────

# reads the command-line flags, defaulting each one from config
def parse_args():
    p = argparse.ArgumentParser(description="exppragvllm")
    p.add_argument("--forms", nargs="+", default=config.FORMS)
    p.add_argument("--verbs", nargs="+", default=None,
                   help="restrict to these verbs; default is every "
                        "verb each form defines")
    p.add_argument("--levels", nargs="+", default=config.LEVELS)
    p.add_argument("--opponents", nargs="+", default=config.OPPONENTS)
    p.add_argument("--seeds", nargs="+", type=int, default=config.SEEDS)
    p.add_argument("--rounds", type=int, default=config.TOTAL_ROUNDS)
    p.add_argument("--tag", default=None)
    p.add_argument("--workers", type=int, default=config.MAX_CONCURRENT)
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--yes", action="store_true")
    return p.parse_args()


# builds the cell list, runs it through the worker pool, and writes results
def main():
    args = parse_args()
    if args.self_test:
        return self_test()
    if args.dry_run:
        # Without a stub a dry run would fail every call against a server that
        # is not there and still report a clean-looking run.
        import scoring
        scoring.use_stub()

    config.TOTAL_ROUNDS = args.rounds
    conds = [(f, v) for f, v in prompts.conditions()
             if f in args.forms
             and (args.verbs is None or v in args.verbs)]
    cells = [(f, v, l, o, s) for (f, v) in conds
             for l in args.levels for o in args.opponents
             for s in args.seeds]
    tag = args.tag or (args.opponents[0] if len(args.opponents) == 1 else "main")

    db_path = database.next_path(tag)
    conn = database.connect(db_path)
    database.write_meta(conn, {
        "status": "running",
        "started": datetime.datetime.now().isoformat(timespec="seconds"),
        "arm": config.ARM, "model_kind": config.MODEL_KIND,
        "model": config.VLLM_MODEL_PATH, "label_scheme": config.LABEL_SCHEME,
        "total_rounds": args.rounds, "probe_from": config.PROBE_FROM,
        "opponents": ",".join(args.opponents), "levels": ",".join(args.levels),
        "forms": ",".join(args.forms),
        "conditions": len(conds),
        "probe_dense_to": config.PROBE_DENSE_TO,
        "probe_sparse_every": config.PROBE_SPARSE_EVERY, "seeds": ",".join(map(str, args.seeds)),
        "feedback": config.FEEDBACK,
        "max_new_tokens": config.MAX_NEW_TOKENS,
        "enable_thinking": config.ENABLE_THINKING,
        "presence_penalty": config.PRESENCE_PENALTY,
        "require_answer_line": config.REQUIRE_ANSWER_LINE,
        "top_logprobs": config.TOP_LOGPROBS,
        "dry_run": args.dry_run})

    print("=" * 78)
    print(f"  exppragvllm — {config.ARM} / {config.MODEL_KIND}")
    print("=" * 78)
    print(f"  {config.VLLM_MODEL_PATH}{'  [DRY RUN]' if args.dry_run else ''}")
    print(f"  Forms:     {args.forms}")
    print(f"  Conditions:{len(conds):>3}   Levels: {args.levels}")
    print(f"  Opponents: {args.opponents}   Seeds: {args.seeds}")
    print(f"  Rounds:    {args.rounds}   Cells: {len(cells)}")
    print(f"  Workers:   {args.workers}")
    print(f"  Database:  {db_path}")
    print("=" * 78, flush=True)

    if not args.yes and not args.dry_run:
        if input("  Proceed? [y/N] ").strip().lower() not in ("y", "yes"):
            sys.exit(0)

    done, rows = 0, []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futs = {pool.submit(runner.run_cell, f, v, l, o, s):
                (f, v, l, o, s) for (f, v, l, o, s) in cells}
        for fut in as_completed(futs):
            f, v, l, o, s = futs[fut]
            got = fut.result()
            database.insert(conn, got)
            rows += got
            done += 1
            ok = [r["prediction_correct"] for r in got
                  if r["prediction_correct"] is not None]
            acc = 100 * sum(ok) / len(ok) if ok else 0.0
            print(f"  [{done}/{len(cells)}] {o:<7} {l:<3} {f:<11} {v:<11} s{s}  "
                  f"{acc:5.1f}%", flush=True)

    database.write_meta(conn, {
        "status": "complete",
        "finished": datetime.datetime.now().isoformat(timespec="seconds"),
        "rows": database.count(conn)})
    summary(rows, args, conds)
    conn.close()

    if config.FINAL_COPY_DIR:
        os.makedirs(config.FINAL_COPY_DIR, exist_ok=True)
        shutil.copy2(db_path, config.FINAL_COPY_DIR)
        print(f"\n  Copied to {config.FINAL_COPY_DIR}")
    return 0


# prints the per-condition accuracy table and the baseline comparison
def summary(rows, args, conds):
    # the mean of `key` over rows that have it, as a percentage
    def pct(rs, key):
        v = [r[key] for r in rs if r.get(key) is not None]
        return 100 * sum(v) / len(v) if v else None

    # right-aligned one-decimal formatting, with an em dash for missing values
    def f(v, w=6):
        return f"{v:{w}.1f}" if v is not None else f"{'—':>{w}}"

    print("\n" + "=" * 92)
    print(f"  {config.ARM} / {config.MODEL_KIND}")
    print("=" * 92)

    for o in args.opponents:
        print(f"\n  {o}")
        print(f"    {'form':<12} {'verb':<11} {'lvl':<4} {'acc%':>6} "
              f"{'cov':>6} {'ent':>6} {'margin':>7}   {'answers':<20}")
        for (fm, v) in conds:
            for l in args.levels:
                rs = [r for r in rows if r["opponent"] == o
                      and r["form"] == fm and r["verb"] == v
                      and r["task_level"] == l]
                if not rs:
                    continue
                c = Counter(r["prediction"] for r in rs if r["prediction"])
                tot = sum(c.values()) or 1
                ans = " ".join(f"{m}:{100*c[m]/tot:4.1f}%" for m in game.MOVES)
                cov = pct(rs, "pred_coverage")
                print(f"    {fm:<12} {v:<11} {l:<4} "
                      f"{f(pct(rs,'prediction_correct'))} "
                      f"{f(cov/100 if cov is not None else None)} "
                      f"{f(sum(r['pred_entropy'] for r in rs)/len(rs))} "
                      f"{f(sum(r['pred_margin'] for r in rs)/len(rs), 7)}   "
                      f"{ans:<20}")

    print("\n  Baselines (all / switch rounds), pooled per opponent.")
    print("  Accuracy at or below these is not prediction.\n")
    for o in args.opponents:
        rs = [r for r in rows if r["opponent"] == o]
        sw = [r for r in rs if r["switched"]]
        parts = [f"{lab} {f(pct(rs,k),5)}/{f(pct(sw,k),5)}"
                 for k, lab in (("b_opp_last", "persist"),
                                ("b_own_last", "own last"),
                                ("b_modal", "modal"),
                                ("b_true_rule", "true rule"))]
        print(f"    {o:<9} " + "   ".join(parts))

    low = [r for r in rows if (r.get("pred_coverage") or 1) < 0.90]
    print(f"\n  Coverage below 0.90: {len(low)} of {len(rows)} "
          f"({100*len(low)/max(1,len(rows)):.1f}%)")
    print("  Read coverage.py before quoting any accuracy figure.")
    print("=" * 92)


if __name__ == "__main__":
    sys.exit(main() or 0)
